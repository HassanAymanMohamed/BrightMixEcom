
import type { Metadata } from 'next';
import './globals.css';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from "@/components/ui/toaster";
import { LocalizationProvider } from '@/contexts/localization-context';
import { LoadingProvider } from '@/contexts/loading-context';
import { GlobalLoadingIndicator } from '@/components/global-loading-indicator'; // Import the new client component

export const metadata: Metadata = {
  title: 'Ethereal Finds',
  description: 'Discover unique and exquisite products.',
  icons: {
    icon: '/favicon.ico',
  }
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" dir="ltr" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased min-h-screen flex flex-col" suppressHydrationWarning>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <LocalizationProvider>
            <LoadingProvider>
              {/* The app/loading.tsx file will handle route transition loading bars automatically. */}
              {/* GlobalLoadingIndicator handles manual full-screen loads triggered via LoadingContext. */}
              {children}
              <GlobalLoadingIndicator />
            </LoadingProvider>
          </LocalizationProvider>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
