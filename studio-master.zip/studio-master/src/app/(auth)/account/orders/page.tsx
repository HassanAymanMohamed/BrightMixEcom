
"use client";

import React from 'react';
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { Package, Eye, Download } from "lucide-react";
import { useLocalization } from '@/contexts/localization-context';

// Mock data for orders - assuming 'total' is in USD
const mockOrders = [
  { id: "ORD12345", date: "2023-10-26", status: "Delivered", totalUSD: 155.50, items: 2 },
  { id: "ORD12360", date: "2023-11-05", status: "Shipped", totalUSD: 75.00, items: 1 },
  { id: "ORD12377", date: "2023-11-15", status: "Processing", totalUSD: 220.75, items: 3 },
  { id: "ORD12382", date: "2023-11-20", status: "Cancelled", totalUSD: 45.00, items: 1 },
];

const getStatusBadgeVariant = (status: string) => {
  switch (status.toLowerCase()) {
    case "delivered":
      return "default"; // Using default as success-like
    case "shipped":
      return "secondary";
    case "processing":
      return "outline"; // A neutral processing state
    case "cancelled":
      return "destructive";
    default:
      return "outline";
  }
};


export default function OrdersPage() {
  const { formatPrice, language, currency } = useLocalization();

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-2xl font-headline font-semibold mb-1">Order History</h2>
        <p className="text-muted-foreground">View details of your past and current orders.</p>
      </section>

      {mockOrders.length > 0 ? (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[120px]">Order ID</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Total</TableHead>
              <TableHead className="text-right">Items</TableHead>
              <TableHead className="text-center">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockOrders.map((order) => (
              <TableRow key={order.id}>
                <TableCell className="font-medium">{order.id}</TableCell>
                <TableCell>{order.date}</TableCell>
                <TableCell>
                  <Badge variant={getStatusBadgeVariant(order.status)}>{order.status}</Badge>
                </TableCell>
                <TableCell className="text-right">{formatPrice(order.totalUSD)}</TableCell>
                <TableCell className="text-right">{order.items}</TableCell>
                <TableCell className="text-center space-x-2">
                  <Button variant="ghost" size="icon" asChild aria-label={`View order ${order.id}`}>
                    <Link href={`/account/orders/${order.id}`}><Eye className="h-4 w-4" /></Link>
                  </Button>
                   <Button variant="ghost" size="icon" aria-label={`Download invoice for order ${order.id}`}>
                    <Download className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      ) : (
         <div className="text-center py-12 border-2 border-dashed border-border rounded-lg">
          <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-xl font-headline font-semibold mb-2">No Orders Yet</h3>
          <p className="text-muted-foreground mb-6">
            You haven't placed any orders. Start shopping to see your orders here.
          </p>
          <Button asChild>
            <Link href="/products">Shop Now</Link>
          </Button>
        </div>
      )}
    </div>
  );
}
