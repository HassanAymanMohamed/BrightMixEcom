"use client";

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { MapPin, PlusCircle, Edit2, Trash2, Home, CheckCircle } from "lucide-react";
import { useForm, SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

interface Address {
  id: string;
  type: 'Home' | 'Work' | 'Other';
  fullName: string;
  street: string;
  apartment?: string;
  city: string;
  country: string;
  zip: string;
  isDefault: boolean;
}

const addressSchema = z.object({
  id: z.string().optional(),
  type: z.enum(['Home', 'Work', 'Other']),
  fullName: z.string().min(2, "Full name is required"),
  street: z.string().min(5, "Street address is required"),
  apartment: z.string().optional(),
  city: z.string().min(2, "City is required"),
  country: z.string().min(2, "Country is required"),
  zip: z.string().min(3, "ZIP code is required"),
  isDefault: z.boolean().optional(),
});

type AddressFormData = z.infer<typeof addressSchema>;

// Mock data for addresses
const mockAddresses: Address[] = [
  { id: "addr1", type: 'Home', fullName: "Aisha Al-Fahad", street: "123 Palm Tree Lane", city: "Riyadh", country: "Saudi Arabia", zip: "11564", isDefault: true },
  { id: "addr2", type: 'Work', fullName: "Aisha Al-Fahad", street: "456 Business Bay Tower", apartment: "Suite 701", city: "Dubai", country: "UAE", zip: "00000", isDefault: false },
];

export default function AddressesPage() {
  const [addresses, setAddresses] = useState<Address[]>(mockAddresses);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<AddressFormData>({
    resolver: zodResolver(addressSchema),
  });

  const openAddForm = () => {
    reset({ type: 'Home', isDefault: false }); // Reset with default values
    setEditingAddress(null);
    setIsFormOpen(true);
  };

  const openEditForm = (address: Address) => {
    setEditingAddress(address);
    reset(address); // Populate form with address data
    setIsFormOpen(true);
  };

  const onSubmit: SubmitHandler<AddressFormData> = (data) => {
    if (editingAddress) {
      setAddresses(prev => prev.map(addr => addr.id === editingAddress.id ? { ...editingAddress, ...data } : addr));
    } else {
      setAddresses(prev => [...prev, { ...data, id: `addr${Date.now()}` }]);
    }
    setIsFormOpen(false);
    reset();
  };
  
  const deleteAddress = (addressId: string) => {
    setAddresses(prev => prev.filter(addr => addr.id !== addressId));
  };

  const setDefaultAddress = (addressId: string) => {
    setAddresses(prev => prev.map(addr => ({ ...addr, isDefault: addr.id === addressId })));
  };


  return (
    <div className="space-y-6">
      <section className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-headline font-semibold mb-1">Manage Addresses</h2>
          <p className="text-muted-foreground">Add, edit, or remove your shipping addresses.</p>
        </div>
         <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogTrigger asChild>
            <Button onClick={openAddForm}><PlusCircle className="mr-2 h-4 w-4" /> Add New Address</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>{editingAddress ? 'Edit Address' : 'Add New Address'}</DialogTitle>
              <DialogDescription>
                {editingAddress ? 'Update the details of your address.' : 'Enter the details for your new shipping address.'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4">
              {/* Form fields */}
              <div>
                <Label htmlFor="fullName">Full Name</Label>
                <Input id="fullName" {...register("fullName")} className="mt-1" />
                {errors.fullName && <p className="text-xs text-destructive mt-1">{errors.fullName.message}</p>}
              </div>
              <div>
                <Label htmlFor="street">Street Address</Label>
                <Input id="street" {...register("street")} className="mt-1" />
                 {errors.street && <p className="text-xs text-destructive mt-1">{errors.street.message}</p>}
              </div>
              <div>
                <Label htmlFor="apartment">Apartment, suite, etc. (optional)</Label>
                <Input id="apartment" {...register("apartment")} className="mt-1" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="city">City</Label>
                  <Input id="city" {...register("city")} className="mt-1" />
                  {errors.city && <p className="text-xs text-destructive mt-1">{errors.city.message}</p>}
                </div>
                <div>
                  <Label htmlFor="country">Country</Label>
                  <Input id="country" {...register("country")} className="mt-1" />
                  {errors.country && <p className="text-xs text-destructive mt-1">{errors.country.message}</p>}
                </div>
                <div>
                  <Label htmlFor="zip">ZIP Code</Label>
                  <Input id="zip" {...register("zip")} className="mt-1" />
                  {errors.zip && <p className="text-xs text-destructive mt-1">{errors.zip.message}</p>}
                </div>
              </div>
               <div>
                <Label htmlFor="type">Address Type</Label>
                 <select id="type" {...register("type")} className="w-full mt-1 p-2 border border-input rounded-md text-sm">
                    <option value="Home">Home</option>
                    <option value="Work">Work</option>
                    <option value="Other">Other</option>
                 </select>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="isDefault" {...register("isDefault")} />
                <Label htmlFor="isDefault" className="text-sm font-normal">Set as default shipping address</Label>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                    <Button type="button" variant="outline">Cancel</Button>
                </DialogClose>
                <Button type="submit">{editingAddress ? 'Save Changes' : 'Add Address'}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </section>

      {addresses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {addresses.map((address) => (
            <Card key={address.id} className={`relative ${address.isDefault ? 'border-primary ring-1 ring-primary' : ''}`}>
              {address.isDefault && (
                <div className="absolute top-2 right-2 flex items-center text-xs text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                  <CheckCircle className="h-3 w-3 mr-1" /> Default
                </div>
              )}
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                    <Home className="mr-2 h-5 w-5 text-primary"/> {address.type} Address
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm space-y-1 text-muted-foreground">
                <p className="font-medium text-foreground">{address.fullName}</p>
                <p>{address.street}</p>
                {address.apartment && <p>{address.apartment}</p>}
                <p>{address.city}, {address.zip}</p>
                <p>{address.country}</p>
              </CardContent>
              <CardFooter className="flex justify-between items-center pt-4 border-t">
                {!address.isDefault && (
                  <Button variant="link" size="sm" className="p-0 h-auto text-primary" onClick={() => setDefaultAddress(address.id)}>
                    Set as Default
                  </Button>
                )}
                <div className="flex-grow"></div> {/* Spacer */}
                <div className="space-x-2">
                  <Button variant="outline" size="icon" onClick={() => openEditForm(address)} aria-label="Edit address">
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button variant="destructive" size="icon" onClick={() => deleteAddress(address.id)} aria-label="Delete address" disabled={address.isDefault}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 border-2 border-dashed border-border rounded-lg">
          <MapPin className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-xl font-headline font-semibold mb-2">No Addresses Saved</h3>
          <p className="text-muted-foreground mb-6">
            Add a shipping address to make checkout faster.
          </p>
           <Button onClick={openAddForm}><PlusCircle className="mr-2 h-4 w-4" /> Add New Address</Button>
        </div>
      )}
    </div>
  );
}
