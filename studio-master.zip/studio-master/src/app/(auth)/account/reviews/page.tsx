"use client";

import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Star, Edit3, Trash2, ShoppingBag } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

// Mock data for reviews
const mockUserReviews = [
  { 
    id: "rev1", 
    productId: "1", 
    productName: "Celestial Silk Scarf", 
    productImage: "https://placehold.co/80x80.png?a=1",
    rating: 5, 
    date: "2023-10-15", 
    text: "Absolutely beautiful scarf! The silk is so soft and the print is gorgeous. Highly recommend." 
  },
  { 
    id: "rev2", 
    productId: "3", 
    productName: "Enchanted Forest Candle", 
    productImage: "https://placehold.co/80x80.png?c=1",
    rating: 4, 
    date: "2023-09-22", 
    text: "Smells wonderful and creates a very cozy atmosphere. Wish it burned a bit longer, but overall a great candle." 
  },
];

const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Star
          key={i}
          className={`h-4 w-4 ${i <= Math.round(rating) ? 'fill-accent text-accent' : 'text-muted-foreground'}`}
        />
      );
    }
    return stars;
  };

export default function ReviewsPage() {
  const handleEditReview = (reviewId: string) => {
    // Placeholder for edit review logic
    console.log("Edit review:", reviewId);
  };

  const handleDeleteReview = (reviewId: string) => {
    // Placeholder for delete review logic
    console.log("Delete review:", reviewId);
  };

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-2xl font-headline font-semibold mb-1">My Reviews</h2>
        <p className="text-muted-foreground">Manage and view reviews you've written for products.</p>
      </section>

      {mockUserReviews.length > 0 ? (
        <div className="space-y-4">
          {mockUserReviews.map((review) => (
            <Card key={review.id}>
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                        <div className="relative w-16 h-16 rounded-md overflow-hidden border flex-shrink-0">
                            <Image src={review.productImage} alt={review.productName} fill className="object-cover" data-ai-hint="product thumbnail"/>
                        </div>
                        <div>
                            <Link href={`/products/${review.productId}`}>
                                <CardTitle className="text-lg hover:text-primary transition-colors">{review.productName}</CardTitle>
                            </Link>
                            <div className="flex items-center mt-1">
                                {renderStars(review.rating)}
                            </div>
                        </div>
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">{review.date}</span>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-foreground/90 leading-relaxed">{review.text}</p>
              </CardContent>
              <CardFooter className="flex justify-end space-x-2">
                <Button variant="outline" size="sm" onClick={() => handleEditReview(review.id)}>
                  <Edit3 className="h-3 w-3 mr-1.5" /> Edit
                </Button>
                <Button variant="destructive" size="sm" onClick={() => handleDeleteReview(review.id)}>
                  <Trash2 className="h-3 w-3 mr-1.5" /> Delete
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 border-2 border-dashed border-border rounded-lg">
          <Star className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-xl font-headline font-semibold mb-2">No Reviews Yet</h3>
          <p className="text-muted-foreground mb-6">
            You haven't reviewed any products. Share your thoughts on purchased items!
          </p>
          <Button asChild>
            <Link href="/account/orders"><ShoppingBag className="mr-2 h-4 w-4"/> View Your Orders</Link>
          </Button>
        </div>
      )}
       <div className="mt-8">
        <Button variant="outline" asChild>
          <Link href="/products">Review More Products</Link>
        </Button>
      </div>
    </div>
  );
}