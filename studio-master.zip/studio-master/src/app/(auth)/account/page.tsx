
"use client"; 

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Package, Star, MapPin, CreditCard, Edit } from "lucide-react";
import { useLocalization } from '@/contexts/localization-context'; // Assuming this will be created

// Note: This component is a server component by default in App Router.
// To use hooks like useLocalization, it needs to be a Client Component.
// Or, pass localization data as props from a Client Component parent or via Server Context (advanced).
// For simplicity, we'll make it a client component if direct hook usage is needed.
// However, if it's just for display, we can assume localization props are passed down.
// For this example, let's make it a client component to use the hook directly.


export default function AccountOverviewPage() {
  const { formatPrice, language, currency } = useLocalization(); // Now we can use the hook

  // Mock data for demonstration
  const user = {
    name: "Aisha Al-Fahad",
    email: "aisha.alfahad@example.com",
    recentOrder: {
      id: "ORD12345",
      date: "2023-10-26",
      status: "Delivered",
      totalUSD: 155.50, // Assuming base price in USD
    },
    points: 1250, // Loyalty points example
  };

  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-headline font-semibold mb-1">Welcome back, {user.name}!</h2>
        <p className="text-muted-foreground">{user.email}</p>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Recent Order</CardTitle>
            <Package className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {user.recentOrder ? (
              <>
                <p className="text-sm"><strong>Order ID:</strong> {user.recentOrder.id}</p>
                <p className="text-sm"><strong>Date:</strong> {user.recentOrder.date}</p>
                <p className="text-sm"><strong>Status:</strong> <span className="font-semibold text-green-600">{user.recentOrder.status}</span></p>
                <p className="text-sm"><strong>Total:</strong> {formatPrice(user.recentOrder.totalUSD)}</p>
                <Button variant="outline" size="sm" asChild className="mt-3">
                  <Link href={`/account/orders/${user.recentOrder.id}`}>View Details</Link>
                </Button>
              </>
            ) : (
              <p className="text-sm text-muted-foreground">You have no recent orders.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-medium">Loyalty Points</CardTitle>
            <Star className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">{user.points}</div>
            <p className="text-xs text-muted-foreground">points available to redeem</p>
            <Button variant="link" size="sm" asChild className="px-0 mt-2">
              <Link href="/loyalty-program">Learn More</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      <section className="space-y-4">
        <h3 className="text-xl font-headline font-semibold">Quick Actions</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <Button variant="outline" asChild className="justify-start h-auto py-3">
            <Link href="/account/orders" className="flex items-center">
              <Package className="mr-3 h-5 w-5 text-primary" />
              <div>
                <span className="font-medium">Track My Orders</span>
                <p className="text-xs text-muted-foreground">View order history and status</p>
              </div>
            </Link>
          </Button>
          <Button variant="outline" asChild className="justify-start h-auto py-3">
            <Link href="/account/addresses" className="flex items-center">
              <MapPin className="mr-3 h-5 w-5 text-primary" />
              <div>
                <span className="font-medium">Manage Addresses</span>
                <p className="text-xs text-muted-foreground">Update your shipping addresses</p>
              </div>
            </Link>
          </Button>
          <Button variant="outline" asChild className="justify-start h-auto py-3">
            <Link href="/account/payment-methods" className="flex items-center">
              <CreditCard className="mr-3 h-5 w-5 text-primary" />
              <div>
                <span className="font-medium">Payment Methods</span>
                <p className="text-xs text-muted-foreground">Add or edit payment options</p>
              </div>
            </Link>
          </Button>
        </div>
      </section>
       <section>
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-medium">Account Details</CardTitle>
            <CardDescription>Review and update your personal information.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm"><strong>Name:</strong> {user.name}</p>
            <p className="text-sm"><strong>Email:</strong> {user.email}</p>
            {/* Add more details like phone number if available */}
            <Button variant="outline" size="sm" asChild className="mt-3">
              <Link href="/account/details"><Edit className="mr-2 h-3 w-3"/> Edit Details</Link>
            </Button>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
