"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  LayoutDashboard,
  Package,
  Star,
  MapPin,
  CreditCard,
  LogOut,
  UserCircle,
} from "lucide-react";

const sidebarNavItems = [
  {
    title: "Overview",
    href: "/account",
    icon: LayoutDashboard,
  },
  {
    title: "Orders",
    href: "/account/orders",
    icon: Package,
  },
  {
    title: "My Reviews",
    href: "/account/reviews",
    icon: Star,
  },
  {
    title: "Addresses",
    href: "/account/addresses",
    icon: MapPin,
  },
  {
    title: "Payment Methods",
    href: "/account/payment-methods",
    icon: CreditCard,
  },
  {
    title: "Account Details",
    href: "/account/details",
    icon: UserCircle,
  },
];

export default function AccountLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="container mx-auto py-8">
      <header className="mb-10">
        <h1 className="text-4xl font-headline font-bold text-primary">My Account</h1>
        <p className="text-lg text-muted-foreground mt-1">Manage your orders, preferences, and personal details.</p>
      </header>
      <div className="flex flex-col md:flex-row gap-8 items-start">
        <aside className="w-full md:w-1/4 lg:w-1/5">
          <Card>
            <CardContent className="p-4">
              <ScrollArea className="h-auto md:max-h-[calc(100vh-12rem)]">
                <nav className="flex flex-col space-y-1">
                  {sidebarNavItems.map((item) => (
                    <Link key={item.href} href={item.href}>
                      <Button
                        variant={pathname === item.href ? "default" : "ghost"}
                        className={cn(
                          "w-full justify-start text-sm",
                          pathname === item.href && "bg-primary text-primary-foreground hover:bg-primary/90",
                          pathname !== item.href && "hover:bg-muted/50"
                        )}
                      >
                        <item.icon className="mr-2 h-4 w-4" />
                        {item.title}
                      </Button>
                    </Link>
                  ))}
                   <Button
                      variant="ghost"
                      className="w-full justify-start text-sm text-destructive hover:bg-destructive/10 hover:text-destructive"
                      onClick={() => { /* Implement logout logic */ }}
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      Logout
                    </Button>
                </nav>
              </ScrollArea>
            </CardContent>
          </Card>
        </aside>
        <main className="w-full md:w-3/4 lg:w-4/5">
          <Card className="shadow-sm">
            <CardContent className="p-6 md:p-8">
              {children}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
