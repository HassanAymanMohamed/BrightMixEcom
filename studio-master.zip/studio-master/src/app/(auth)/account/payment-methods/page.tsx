"use client";

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import { CreditCard, PlusCircle, Edit2, Trash2, CheckCircle } from "lucide-react";
import { useForm, SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Checkbox } from "@/components/ui/checkbox";

interface PaymentMethod {
  id: string;
  type: 'Visa' | 'Mastercard' | 'Amex'; // Example card types
  last4: string;
  expiryMonth: string;
  expiryYear: string;
  isDefault: boolean;
}

const paymentMethodSchema = z.object({
  id: z.string().optional(),
  type: z.enum(['Visa', 'Mastercard', 'Amex']),
  cardNumber: z.string().min(16, "Card number must be 16 digits").max(16, "Card number must be 16 digits").regex(/^\d+$/, "Card number must be digits"),
  expiryDate: z.string().regex(/^(0[1-9]|1[0-2])\/\d{2}$/, "Expiry date must be MM/YY"),
  cvc: z.string().min(3, "CVC must be 3-4 digits").max(4, "CVC must be 3-4 digits").regex(/^\d+$/, "CVC must be digits"),
  cardHolderName: z.string().min(2, "Cardholder name is required"),
  isDefault: z.boolean().optional(),
});

type PaymentMethodFormData = z.infer<typeof paymentMethodSchema>;


// Mock data for payment methods
const mockPaymentMethods: PaymentMethod[] = [
  { id: "pm1", type: 'Visa', last4: "4242", expiryMonth: "12", expiryYear: "25", isDefault: true },
  { id: "pm2", type: 'Mastercard', last4: "5555", expiryMonth: "08", expiryYear: "26", isDefault: false },
];

const CardIcon = ({ type }: { type: PaymentMethod['type'] }) => {
  // In a real app, you'd use actual card brand SVGs
  if (type === 'Visa') return <span className="font-bold text-blue-600">VISA</span>;
  if (type === 'Mastercard') return <span className="font-bold text-red-600">MC</span>;
  if (type === 'Amex') return <span className="font-bold text-sky-500">AMEX</span>;
  return <CreditCard className="h-6 w-6 text-muted-foreground"/>;
};

export default function PaymentMethodsPage() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(mockPaymentMethods);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingMethod, setEditingMethod] = useState<PaymentMethod | null>(null);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<PaymentMethodFormData>({
    resolver: zodResolver(paymentMethodSchema),
  });

  const openAddForm = () => {
    reset({ type: 'Visa', isDefault: false });
    setEditingMethod(null);
    setIsFormOpen(true);
  };

  const openEditForm = (method: PaymentMethod) => {
    setEditingMethod(method);
    // Note: Full card number is not stored/editable for PCI compliance.
    // This form would typically be for adding new cards or editing expiry/default status.
    reset({ 
        type: method.type, 
        cardHolderName: "Aisha Al-Fahad", // Prefill from user data
        expiryDate: `${method.expiryMonth}/${method.expiryYear.slice(-2)}`,
        isDefault: method.isDefault,
        // cardNumber and CVC are not prefilled for editing an existing card
    });
    setIsFormOpen(true);
  };

  const onSubmit: SubmitHandler<PaymentMethodFormData> = (data) => {
    const [expiryMonth, expiryYearSuffix] = data.expiryDate.split('/');
    const newMethod: PaymentMethod = {
      id: editingMethod ? editingMethod.id : `pm${Date.now()}`,
      type: data.type,
      last4: data.cardNumber.slice(-4),
      expiryMonth,
      expiryYear: `20${expiryYearSuffix}`, // Assuming 21st century
      isDefault: data.isDefault || false,
    };

    if (editingMethod) {
      setPaymentMethods(prev => prev.map(pm => pm.id === editingMethod.id ? newMethod : pm));
    } else {
      setPaymentMethods(prev => [...prev, newMethod]);
    }
    if (newMethod.isDefault) {
       setDefaultPaymentMethod(newMethod.id);
    }
    setIsFormOpen(false);
    reset();
  };
  
  const deletePaymentMethod = (methodId: string) => {
    setPaymentMethods(prev => prev.filter(pm => pm.id !== methodId));
  };

  const setDefaultPaymentMethod = (methodId: string) => {
    setPaymentMethods(prev => prev.map(pm => ({ ...pm, isDefault: pm.id === methodId })));
  };


  return (
    <div className="space-y-6">
      <section className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-headline font-semibold mb-1">Payment Methods</h2>
          <p className="text-muted-foreground">Manage your saved payment options for faster checkout.</p>
        </div>
        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogTrigger asChild>
            <Button onClick={openAddForm}><PlusCircle className="mr-2 h-4 w-4" /> Add New Card</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>{editingMethod ? 'Edit Payment Method' : 'Add New Payment Method'}</DialogTitle>
              <DialogDescription>
                {editingMethod ? 'Update your card details.' : 'Securely add a new credit or debit card.'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4">
              <div>
                <Label htmlFor="cardHolderName">Cardholder Name</Label>
                <Input id="cardHolderName" {...register("cardHolderName")} className="mt-1" />
                {errors.cardHolderName && <p className="text-xs text-destructive mt-1">{errors.cardHolderName.message}</p>}
              </div>
              <div>
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input id="cardNumber" {...register("cardNumber")} placeholder="•••• •••• •••• ••••" className="mt-1" />
                {errors.cardNumber && <p className="text-xs text-destructive mt-1">{errors.cardNumber.message}</p>}
              </div>
              <div className="grid grid-cols-3 gap-4">
                 <div>
                    <Label htmlFor="type">Card Type</Label>
                    <select id="type" {...register("type")} className="w-full mt-1 p-2 border border-input rounded-md text-sm h-10">
                        <option value="Visa">Visa</option>
                        <option value="Mastercard">Mastercard</option>
                        <option value="Amex">Amex</option>
                    </select>
                </div>
                <div>
                  <Label htmlFor="expiryDate">Expiry Date (MM/YY)</Label>
                  <Input id="expiryDate" {...register("expiryDate")} placeholder="MM/YY" className="mt-1" />
                  {errors.expiryDate && <p className="text-xs text-destructive mt-1">{errors.expiryDate.message}</p>}
                </div>
                <div>
                  <Label htmlFor="cvc">CVC</Label>
                  <Input id="cvc" {...register("cvc")} placeholder="•••" className="mt-1" />
                  {errors.cvc && <p className="text-xs text-destructive mt-1">{errors.cvc.message}</p>}
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="isDefaultPayment" {...register("isDefault")} />
                <Label htmlFor="isDefaultPayment" className="text-sm font-normal">Set as default payment method</Label>
              </div>
              <DialogFooter>
                 <DialogClose asChild>
                    <Button type="button" variant="outline">Cancel</Button>
                </DialogClose>
                <Button type="submit">{editingMethod ? 'Save Changes' : 'Add Card'}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </section>

      {paymentMethods.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {paymentMethods.map((method) => (
            <Card key={method.id} className={`relative ${method.isDefault ? 'border-primary ring-1 ring-primary' : ''}`}>
               {method.isDefault && (
                <div className="absolute top-2 right-2 flex items-center text-xs text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                  <CheckCircle className="h-3 w-3 mr-1" /> Default
                </div>
              )}
              <CardHeader>
                <div className="flex items-center justify-between">
                     <CardTitle className="flex items-center text-lg"><CardIcon type={method.type} /> <span className="ml-2">Ending in {method.last4}</span></CardTitle>
                </div>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p>Expires: {method.expiryMonth}/{method.expiryYear.slice(-2)}</p>
              </CardContent>
              <CardFooter className="flex justify-between items-center pt-4 border-t">
                 {!method.isDefault && (
                  <Button variant="link" size="sm" className="p-0 h-auto text-primary" onClick={() => setDefaultPaymentMethod(method.id)}>
                    Set as Default
                  </Button>
                )}
                <div className="flex-grow"></div> {/* Spacer */}
                <div className="space-x-2">
                  <Button variant="outline" size="icon" onClick={() => openEditForm(method)} aria-label="Edit payment method">
                    <Edit2 className="h-4 w-4" />
                  </Button>
                  <Button variant="destructive" size="icon" onClick={() => deletePaymentMethod(method.id)} aria-label="Delete payment method" disabled={method.isDefault}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 border-2 border-dashed border-border rounded-lg">
          <CreditCard className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-xl font-headline font-semibold mb-2">No Payment Methods Saved</h3>
          <p className="text-muted-foreground mb-6">
            Add a payment method for a quicker checkout experience.
          </p>
           <Button onClick={openAddForm}><PlusCircle className="mr-2 h-4 w-4"/> Add New Card</Button>
        </div>
      )}
    </div>
  );
}
