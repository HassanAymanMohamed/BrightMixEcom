"use client";

import React from 'react';
import { useForm, SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from '@/hooks/use-toast';
import { UserCircle, Save } from "lucide-react";

const accountDetailsSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().optional(),
});

type AccountDetailsFormData = z.infer<typeof accountDetailsSchema>;

// Mock user data
const mockUser = {
  firstName: "Aisha",
  lastName: "Al-Fahad",
  email: "aisha.alfahad@example.com",
  phone: "+966 50 123 4567",
};

export default function AccountDetailsPage() {
  const { toast } = useToast();
  const { register, handleSubmit, formState: { errors, isDirty, isSubmitting } } = useForm<AccountDetailsFormData>({
    resolver: zodResolver(accountDetailsSchema),
    defaultValues: mockUser, // Pre-fill form with mock user data
  });

  const onSubmit: SubmitHandler<AccountDetailsFormData> = async (data) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log("Updated account details:", data);
    toast({
      title: "Details Updated",
      description: "Your account details have been successfully updated.",
    });
    // In a real app, you might want to reset form with new data or re-fetch user data
  };

  const passwordChangeSchema = z.object({
    currentPassword: z.string().min(8, "Current password must be at least 8 characters"),
    newPassword: z.string().min(8, "New password must be at least 8 characters"),
    confirmPassword: z.string().min(8, "Confirm password must be at least 8 characters"),
  }).refine(data => data.newPassword === data.confirmPassword, {
    message: "New passwords don't match",
    path: ["confirmPassword"],
  });

  type PasswordChangeFormData = z.infer<typeof passwordChangeSchema>;
  
  const { register: registerPassword, handleSubmit: handleSubmitPassword, formState: { errors: passwordErrors, isSubmitting: isPasswordSubmitting }, reset: resetPasswordForm } = useForm<PasswordChangeFormData>({
    resolver: zodResolver(passwordChangeSchema),
  });

  const onPasswordSubmit: SubmitHandler<PasswordChangeFormData> = async (data) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log("Password change request:", data.newPassword ? "New password set" : "No new password");
    toast({
      title: "Password Updated",
      description: "Your password has been successfully updated.",
    });
    resetPasswordForm();
  };


  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-headline font-semibold mb-1">Account Details</h2>
        <p className="text-muted-foreground">Update your personal information and manage your password.</p>
      </section>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center"><UserCircle className="mr-2 h-5 w-5 text-primary" /> Personal Information</CardTitle>
          <CardDescription>Keep your personal details up to date.</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName">First Name</Label>
                <Input id="firstName" {...register("firstName")} className="mt-1" />
                {errors.firstName && <p className="text-xs text-destructive mt-1">{errors.firstName.message}</p>}
              </div>
              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input id="lastName" {...register("lastName")} className="mt-1" />
                {errors.lastName && <p className="text-xs text-destructive mt-1">{errors.lastName.message}</p>}
              </div>
            </div>
            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input id="email" type="email" {...register("email")} className="mt-1" />
              {errors.email && <p className="text-xs text-destructive mt-1">{errors.email.message}</p>}
            </div>
            <div>
              <Label htmlFor="phone">Phone Number (Optional)</Label>
              <Input id="phone" type="tel" {...register("phone")} className="mt-1" />
              {errors.phone && <p className="text-xs text-destructive mt-1">{errors.phone.message}</p>}
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={!isDirty || isSubmitting}>
              <Save className="mr-2 h-4 w-4" /> {isSubmitting ? "Saving..." : "Save Changes"}
            </Button>
          </CardFooter>
        </form>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Change Password</CardTitle>
          <CardDescription>Update your account password regularly for security.</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmitPassword(onPasswordSubmit)}>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="currentPassword">Current Password</Label>
              <Input id="currentPassword" type="password" {...registerPassword("currentPassword")} className="mt-1" />
              {passwordErrors.currentPassword && <p className="text-xs text-destructive mt-1">{passwordErrors.currentPassword.message}</p>}
            </div>
            <div>
              <Label htmlFor="newPassword">New Password</Label>
              <Input id="newPassword" type="password" {...registerPassword("newPassword")} className="mt-1" />
              {passwordErrors.newPassword && <p className="text-xs text-destructive mt-1">{passwordErrors.newPassword.message}</p>}
            </div>
            <div>
              <Label htmlFor="confirmPassword">Confirm New Password</Label>
              <Input id="confirmPassword" type="password" {...registerPassword("confirmPassword")} className="mt-1" />
              {passwordErrors.confirmPassword && <p className="text-xs text-destructive mt-1">{passwordErrors.confirmPassword.message}</p>}
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={isPasswordSubmitting}>
              <Save className="mr-2 h-4 w-4" /> {isPasswordSubmitting ? "Updating..." : "Update Password"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
