"use client";

import Image from 'next/image';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Users, Target, Feather, Sparkles } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="space-y-16 py-8">
      <section className="text-center">
        <Feather className="mx-auto h-16 w-16 text-primary mb-6 opacity-80" />
        <h1 className="text-5xl font-headline font-bold text-primary mb-4">About Ethereal Finds</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          We believe in the beauty of discovery, the thrill of the unique, and the elegance of the extraordinary. 
          Ethereal Finds is more than just a store; it's a curated journey into a world of exquisite items that inspire and delight.
        </p>
      </section>

      <section className="grid md:grid-cols-2 gap-12 items-center">
        <div>
          <Image 
            src="https://placehold.co/800x600.png?about1" 
            alt="Our Curation Process" 
            width={800} 
            height={600} 
            className="rounded-lg shadow-xl"
            data-ai-hint="artisan craft" 
          />
        </div>
        <div className="space-y-4">
          <Target className="h-10 w-10 text-accent mb-2" />
          <h2 className="text-3xl font-headline font-semibold">Our Mission</h2>
          <p className="text-lg text-foreground/80">
            To bring you a carefully selected collection of products that embody quality, craftsmanship, and a touch of the magical. 
            We scour the globe and partner with talented artisans and unique brands to offer items that you won't find just anywhere.
          </p>
          <p className="text-lg text-foreground/80">
            Our goal is to make your shopping experience seamless, enjoyable, and inspiring, helping you find those perfect pieces that resonate with your personal style and story.
          </p>
        </div>
      </section>

      <section className="grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-4 md:order-last">
          <Sparkles className="h-10 w-10 text-accent mb-2" />
          <h2 className="text-3xl font-headline font-semibold">Our Values</h2>
          <ul className="list-disc list-inside space-y-2 text-lg text-foreground/80">
            <li><strong>Quality & Craftsmanship:</strong> We prioritize items made with care and built to last.</li>
            <li><strong>Uniqueness & Originality:</strong> Discover products that stand out and tell a story.</li>
            <li><strong>Customer Delight:</strong> Your satisfaction is our utmost priority. We strive to exceed expectations.</li>
            <li><strong>Ethical Sourcing:</strong> We are committed to partnering with brands that share our values of fairness and sustainability.</li>
          </ul>
        </div>
        <div>
          <Image 
            src="https://placehold.co/800x600.png?about2" 
            alt="Our Values" 
            width={800} 
            height={600} 
            className="rounded-lg shadow-xl"
            data-ai-hint="ethical handmade"
          />
        </div>
      </section>
      
      <section className="text-center bg-muted/50 py-16 rounded-lg">
        <Users className="mx-auto h-12 w-12 text-primary mb-4" />
        <h2 className="text-3xl font-headline font-semibold mb-6">Meet the (Imaginary) Team</h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
          While Ethereal Finds is a concept, imagine a passionate team of curators, designers, and customer champions dedicated to bringing you the best.
        </p>
        <Button asChild size="lg">
          <Link href="/contact">Get In Touch</Link>
        </Button>
      </section>

       <section className="py-12 text-center">
        <h2 className="text-3xl font-headline font-semibold mb-6">Ready to Discover?</h2>
        <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-8">
          Explore our collections and find something truly special that speaks to you.
        </p>
        <Button asChild size="xl" className="bg-accent hover:bg-accent/90 text-accent-foreground">
          <Link href="/products">Shop Our Collections</Link>
        </Button>
      </section>
    </div>
  );
}