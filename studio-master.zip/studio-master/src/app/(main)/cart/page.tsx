
"use client";

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { mockProducts } from '@/lib/mock-data';
import type { Product } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { X, ShoppingCart, Tag, ArrowRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useLocalization } from '@/contexts/localization-context';

interface CartItem extends Product {
  quantity: number;
}

export default function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [mounted, setMounted] = useState(false);
  const { toast } = useToast();
  const { formatPrice, language, currency } = useLocalization();

  useEffect(() => {
    // Simulate fetching cart items. In a real app, this would come from context/API.
    // Example: add first two mock products to cart with quantity 1 and 2
    const initialCartItems = [
      { ...mockProducts[0], quantity: 1 },
      { ...mockProducts[1], quantity: 2 },
    ].filter(p => p.id) as CartItem[]; // Filter out undefined if mockProducts is short & ensure 'id' exists
    setCartItems(initialCartItems);
    setMounted(true);
  }, []);

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity < 1) {
      removeFromCart(productId);
      return;
    }
    setCartItems(prevItems =>
      prevItems.map(item => (item.id === productId ? { ...item, quantity } : item))
    );
  };

  const removeFromCart = (productId: string) => {
    const product = cartItems.find(item => item.id === productId);
    setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
    if (product) {
      toast({
        title: "Item Removed",
        description: `${product.name} has been removed from your cart.`,
      });
    }
  };

  // Calculations are done in base currency (USD)
  const subtotalUSD = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const estimatedShippingUSD = cartItems.length > 0 ? 5.00 : 0; // Example fixed shipping in USD
  const estimatedTaxUSD = subtotalUSD * 0.08; // Example 8% tax in USD
  const totalUSD = subtotalUSD + estimatedShippingUSD + estimatedTaxUSD;

  if (!mounted) {
    return (
      <div className="space-y-8">
        <div className="h-10 bg-muted rounded w-1/3 animate-pulse mb-2"></div>
        <div className="h-6 bg-muted rounded w-1/2 animate-pulse"></div>
        <div className="lg:flex lg:gap-8">
          <div className="lg:w-2/3 space-y-4">
            {[...Array(2)].map((_, i) => (
              <div key={i} className="flex gap-4 p-4 border rounded-lg bg-card">
                <div className="w-24 h-24 bg-muted rounded animate-pulse"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-5 bg-muted rounded w-3/4 animate-pulse"></div>
                  <div className="h-4 bg-muted rounded w-1/2 animate-pulse"></div>
                  <div className="h-8 bg-muted rounded w-1/4 animate-pulse"></div>
                </div>
                <div className="h-5 w-5 bg-muted rounded-full animate-pulse"></div>
              </div>
            ))}
          </div>
          <div className="lg:w-1/3 mt-8 lg:mt-0">
            <div className="p-6 border rounded-lg bg-card space-y-4">
              <div className="h-8 bg-muted rounded w-1/2 animate-pulse mb-4"></div>
              {[...Array(3)].map((_, j) => (
                <div key={j} className="flex justify-between">
                  <div className="h-4 bg-muted rounded w-1/3 animate-pulse"></div>
                  <div className="h-4 bg-muted rounded w-1/4 animate-pulse"></div>
                </div>
              ))}
              <div className="h-px bg-muted my-4 animate-pulse"></div>
              <div className="flex justify-between">
                <div className="h-6 bg-muted rounded w-1/3 animate-pulse"></div>
                <div className="h-6 bg-muted rounded w-1/4 animate-pulse"></div>
              </div>
              <div className="h-12 bg-muted rounded w-full animate-pulse mt-4"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="text-center py-20 border-2 border-dashed border-border rounded-lg">
        <ShoppingCart className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
        <h1 className="text-3xl font-headline font-bold text-primary mb-2">Your Cart is Empty</h1>
        <p className="text-lg text-muted-foreground mb-6">
          Looks like you haven't added anything to your cart yet.
        </p>
        <Button asChild size="lg">
          <Link href="/products">Start Shopping</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-4xl font-headline font-bold text-primary mb-2">Shopping Cart</h1>
        <p className="text-lg text-muted-foreground">Review your items and proceed to checkout.</p>
      </header>

      <div className="lg:flex lg:gap-12 items-start">
        {/* Cart Items */}
        <div className="lg:w-2/3 space-y-4 mb-8 lg:mb-0">
          {cartItems.map((item) => (
            <Card key={item.id} className="overflow-hidden">
              <CardContent className="p-4 flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                <Link href={`/products/${item.id}`} className="block w-full sm:w-24 h-32 sm:h-24 relative rounded-md overflow-hidden flex-shrink-0">
                  <Image
                    src={item.images[0]}
                    alt={item.name}
                    fill
                    sizes="(max-width: 640px) 100vw, 96px"
                    className="object-cover"
                    data-ai-hint="product thumbnail"
                  />
                </Link>
                <div className="flex-grow">
                  <Link href={`/products/${item.id}`}>
                    <h2 className="text-lg font-semibold hover:text-primary transition-colors">{item.name}</h2>
                  </Link>
                  <p className="text-sm text-muted-foreground">{item.category}</p>
                  <p className="text-md font-semibold text-primary mt-1">{formatPrice(item.price)}</p>
                </div>
                <div className="flex flex-col sm:items-end gap-2 w-full sm:w-auto">
                  <Input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))}
                    min="1"
                    className="w-20 h-9 text-center text-sm"
                    aria-label={`Quantity for ${item.name}`}
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFromCart(item.id)}
                    className="text-destructive hover:text-destructive-foreground hover:bg-destructive/90 text-xs p-1"
                    aria-label={`Remove ${item.name} from cart`}
                  >
                    <X className="h-3 w-3 mr-1" /> Remove
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Order Summary */}
        <aside className="lg:w-1/3 lg:sticky lg:top-24">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl font-headline">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Subtotal</span>
                <span>{formatPrice(subtotalUSD)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Estimated Shipping</span>
                <span>{formatPrice(estimatedShippingUSD)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Estimated Tax</span>
                <span>{formatPrice(estimatedTaxUSD)}</span>
              </div>
              
              <div className="flex items-center gap-2 pt-2">
                <Input type="text" placeholder="Discount code or gift card" className="h-9 text-sm" aria-label="Discount code"/>
                <Button variant="outline" size="sm" className="h-9 shrink-0">Apply</Button>
              </div>
              <Separator className="my-4" />
              <div className="flex justify-between text-lg font-semibold">
                <span>Total</span>
                <span>{formatPrice(totalUSD)}</span>
              </div>
            </CardContent>
            <CardFooter className="flex-col gap-3">
               <Button asChild size="lg" className="w-full bg-accent hover:bg-accent/80 text-accent-foreground">
                <Link href="/checkout">
                  Proceed to Checkout <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <p className="text-xs text-muted-foreground text-center">Shipping & taxes calculated at checkout.</p>
            </CardFooter>
          </Card>
        </aside>
      </div>
    </div>
  );
}
