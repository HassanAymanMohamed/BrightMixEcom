"use client";

import { Truck, RotateCcw, Package, CalendarDays, Globe2 } from 'lucide-react';

export default function ShippingReturnsPage() {
  return (
    <div className="py-8 space-y-12">
      <section className="text-center mb-12">
        <Truck className="mx-auto h-16 w-16 text-primary mb-6 opacity-80" />
        <h1 className="text-5xl font-headline font-bold text-primary mb-4">Shipping & Returns</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Information about our shipping policies, delivery times, and how to make a return.
        </p>
      </section>

      <section className="space-y-8">
        <h2 className="text-3xl font-headline font-semibold text-primary flex items-center">
          <Package className="mr-3 h-7 w-7" /> Shipping Information
        </h2>
        
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold mb-3 flex items-center"><Globe2 className="mr-2 h-5 w-5 text-accent"/> Domestic & International Shipping</h3>
          <p className="text-muted-foreground mb-2">
            We ship both domestically within Saudi Arabia & UAE, and to many international destinations. 
            Shipping costs and options will be calculated at checkout based on your delivery address and the weight/size of your order.
          </p>
          <p className="text-muted-foreground">
            Please note that international orders may be subject to import duties, taxes, and customs processing fees, which are the responsibility of the recipient.
          </p>
        </div>

        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold mb-3 flex items-center"><CalendarDays className="mr-2 h-5 w-5 text-accent"/> Estimated Delivery Times</h3>
          <ul className="list-disc list-inside text-muted-foreground space-y-1">
            <li><strong>Domestic (KSA & UAE):</strong> Typically 3-7 business days.</li>
            <li><strong>GCC Countries:</strong> Typically 5-10 business days.</li>
            <li><strong>Other International Destinations:</strong> Typically 7-21 business days, depending on customs and location.</li>
          </ul>
          <p className="text-sm text-foreground/70 mt-3">
            These are estimates and actual delivery times may vary. You will receive a tracking number once your order has shipped.
          </p>
        </div>

        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold mb-3">Shipping Costs</h3>
          <p className="text-muted-foreground">
            Shipping costs are calculated based on the weight of your order and the shipping destination. 
            The final shipping cost will be displayed at checkout before you complete your purchase. We occasionally offer free shipping promotions, so keep an eye out!
          </p>
        </div>
      </section>

      <section className="space-y-8 pt-8 border-t">
        <h2 className="text-3xl font-headline font-semibold text-primary flex items-center">
          <RotateCcw className="mr-3 h-7 w-7" /> Return Policy
        </h2>

        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold mb-3">Our Promise</h3>
          <p className="text-muted-foreground mb-2">
            We want you to be thrilled with your Ethereal Finds. If you're not completely satisfied with your purchase, we're here to help.
          </p>
        </div>
        
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold mb-3">14-Day Returns</h3>
          <p className="text-muted-foreground mb-2">
            You can return most new, unopened items within 14 days of delivery for a full refund or exchange. 
            Items must be in their original packaging and in the same condition that you received them.
          </p>
          <p className="text-muted-foreground">
            To initiate a return, please contact our customer service team at <a href="mailto:support@etherealfinds.com" className="text-accent hover:underline">support@etherealfinds.com</a> with your order number and reason for return.
          </p>
        </div>

        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold mb-3">Exclusions & Conditions</h3>
          <ul className="list-disc list-inside text-muted-foreground space-y-1">
            <li>Custom-made or personalized items are generally non-returnable unless defective.</li>
            <li>Items marked as 'Final Sale' cannot be returned or exchanged.</li>
            <li>Return shipping costs are typically the responsibility of the customer, unless the return is due to our error (e.g., wrong item shipped, defective product).</li>
            <li>Refunds will be processed to the original method of payment once the returned item is received and inspected.</li>
          </ul>
        </div>
        
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h3 className="text-xl font-semibold mb-3">Damaged or Defective Items</h3>
          <p className="text-muted-foreground">
            If you receive a damaged or defective item, please contact us within 48 hours of delivery with photos of the issue. We will arrange for a replacement or refund.
          </p>
        </div>
      </section>
      
      <section className="text-center mt-12">
        <p className="text-muted-foreground">
          For any further questions regarding shipping or returns, please <a href="/contact" className="text-primary hover:underline">contact our support team</a>.
