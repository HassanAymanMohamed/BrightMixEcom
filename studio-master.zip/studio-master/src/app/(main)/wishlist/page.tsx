"use client";

import React, { useState, useEffect } from 'react';
import { ProductCard } from '@/components/product-card';
import { mockProducts } from '@/lib/mock-data'; // Using mock data for now
import type { Product } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Heart, ShoppingCart } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function WishlistPage() {
  // In a real app, wishlist items would come from context/API
  const [wishlistItems, setWishlistItems] = useState<Product[]>([]);
  const [mounted, setMounted] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Simulate fetching wishlist items
    setWishlistItems(mockProducts.slice(0, 3)); // Example: first 3 mock products
    setMounted(true);
  }, []);

  const removeFromWishlist = (productId: string) => {
    setWishlistItems(prevItems => prevItems.filter(item => item.id !== productId));
    const product = mockProducts.find(p => p.id === productId);
    toast({
      title: "Removed from Wishlist",
      description: `${product?.name} has been removed from your wishlist.`,
    });
  };

  const addAllToCart = () => {
    // Placeholder for adding all items to cart
    toast({
      title: "Items Added to Cart",
      description: `${wishlistItems.length} items from your wishlist have been added to your cart.`,
    });
    // Potentially clear wishlist or mark items as added
  };
  
  if (!mounted) {
    return (
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div className="h-10 bg-muted rounded w-1/3 animate-pulse"></div>
          <div className="h-10 bg-muted rounded w-1/4 animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="rounded-lg border bg-card p-4 space-y-3">
              <div className="aspect-[3/4] bg-muted rounded animate-pulse"></div>
              <div className="h-5 bg-muted rounded animate-pulse w-3/4"></div>
              <div className="h-4 bg-muted rounded animate-pulse w-1/2"></div>
              <div className="h-8 bg-muted rounded animate-pulse w-full"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h1 className="text-4xl font-headline font-bold text-primary mb-2">Your Wishlist</h1>
          <p className="text-lg text-muted-foreground">
            {wishlistItems.length > 0
              ? `You have ${wishlistItems.length} item(s) in your wishlist.`
              : "Your wishlist is currently empty."}
          </p>
        </div>
        {wishlistItems.length > 0 && (
          <Button onClick={addAllToCart} className="mt-4 md:mt-0">
            <ShoppingCart className="mr-2 h-4 w-4" /> Add All to Cart
          </Button>
        )}
      </header>

      {wishlistItems.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {wishlistItems.map((product) => (
            <div key={product.id} className="relative group">
              <ProductCard product={product} />
              <Button
                variant="destructive"
                size="sm"
                className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity z-10"
                onClick={() => removeFromWishlist(product.id)}
                aria-label={`Remove ${product.name} from wishlist`}
              >
                Remove
              </Button>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 border-2 border-dashed border-border rounded-lg">
          <Heart className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
          <h2 className="text-2xl font-headline font-semibold mb-2">Your Wishlist is Empty</h2>
          <p className="text-muted-foreground mb-6">
            Looks like you haven't added any products to your wishlist yet.
          </p>
          <Button asChild>
            <Link href="/products">Start Shopping</Link>
          </Button>
        </div>
      )}
    </div>
  );
}