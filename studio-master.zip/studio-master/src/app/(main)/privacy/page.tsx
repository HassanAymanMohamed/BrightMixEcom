"use client";

import { ShieldAlert, Lock, Database, Cookie } from 'lucide-react';

export default function PrivacyPage() {
  return (
    <div className="py-8 space-y-12">
      <section className="text-center mb-12">
        <ShieldAlert className="mx-auto h-16 w-16 text-primary mb-6 opacity-80" />
        <h1 className="text-5xl font-headline font-bold text-primary mb-4">Privacy Policy</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Your privacy is important to us. This policy explains how Ethereal Finds collects, uses, and protects your personal information.
        </p>
        <p className="text-xs text-muted-foreground mt-2">Last Updated: October 28, 2023 (Placeholder Date)</p>
      </section>

      <section className="space-y-8 max-w-3xl mx-auto text-foreground/90 leading-relaxed">
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3 flex items-center">
            <Database className="mr-3 h-6 w-6" /> 1. Information We Collect
          </h2>
          <p>
            We collect information to provide better services to all our users. The types of personal information we may collect include:
          </p>
          <ul className="list-disc list-inside mt-2 space-y-1">
            <li><strong>Personal Identification Information:</strong> Name, email address, phone number, shipping address, billing address.</li>
            <li><strong>Payment Information:</strong> Credit card details (processed securely by our payment partners, not stored by us), transaction history.</li>
            <li><strong>Account Information:</strong> Username, password, order history, wishlist items, product reviews.</li>
            <li><strong>Technical Information:</strong> IP address, browser type, device information, cookies, and usage data when you interact with our website.</li>
          </ul>
        </div>

        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3">2. How We Use Your Information</h2>
          <p>
            We use the information we collect for various purposes, including:
          </p>
          <ul className="list-disc list-inside mt-2 space-y-1">
            <li>To process and fulfill your orders, including shipping and payment.</li>
            <li>To create and manage your account.</li>
            <li>To communicate with you about your orders, new products, services, and promotional offers (if you opt-in).</li>
            <li>To improve our website, products, and services.</li>
            <li>To personalize your shopping experience and provide AI-driven product recommendations.</li>
            <li>To prevent fraud and enhance the security of our Service.</li>
            <li>To comply with legal obligations.</li>
          </ul>
        </div>
        
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3 flex items-center">
            <Lock className="mr-3 h-6 w-6" /> 3. Data Security
          </h2>
           <p>
            We are committed to protecting the security of your personal information. We use a variety of security technologies and procedures (like SSL encryption) to help protect your personal information from unauthorized access, use, or disclosure. However, no method of transmission over the Internet or method of electronic storage is 100% secure.
          </p>
        </div>

        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3 flex items-center">
            <Cookie className="mr-3 h-6 w-6" /> 4. Cookies and Tracking Technologies
          </h2>
          <p>
            We use cookies and similar tracking technologies to track activity on our Service and hold certain information. Cookies are files with a small amount of data which may include an anonymous unique identifier. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.
          </p>
        </div>
        
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3">5. Third-Party Services</h2>
          <p>
            We may employ third-party companies and individuals to facilitate our Service ("Service Providers"), to provide the Service on our behalf, to perform Service-related services, or to assist us in analyzing how our Service is used. These third parties have access to your Personal Information only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose. This includes payment processors and shipping partners.
          </p>
        </div>

        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3">6. Your Data Rights</h2>
          <p>
            Depending on your location, you may have certain rights regarding your personal data, including the right to access, correct, delete, or restrict its processing. You can usually manage your information through your account settings or by contacting us.
          </p>
        </div>
        
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3">7. Changes to This Privacy Policy</h2>
          <p>
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date. You are advised to review this Privacy Policy periodically for any changes.
          </p>
        </div>
      </section>
      
      <section className="text-center mt-12">
        <p className="text-muted-foreground">
          If you have any questions about this Privacy Policy, please <a href="/contact" className="text-primary hover:underline">contact us</a>.
        </p>
      </section>
    </div>
  );
}