"use client";

import { FileText, ShieldCheck, UserCheck, AlertTriangle } from 'lucide-react';

export default function TermsPage() {
  return (
    <div className="py-8 space-y-12">
      <section className="text-center mb-12">
        <FileText className="mx-auto h-16 w-16 text-primary mb-6 opacity-80" />
        <h1 className="text-5xl font-headline font-bold text-primary mb-4">Terms & Conditions</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Please read these Terms & Conditions carefully before using the Ethereal Finds website and services.
        </p>
         <p className="text-xs text-muted-foreground mt-2">Last Updated: October 28, 2023 (Placeholder Date)</p>
      </section>

      <section className="space-y-8 max-w-3xl mx-auto text-foreground/90 leading-relaxed">
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3 flex items-center">
            <UserCheck className="mr-3 h-6 w-6" /> 1. Acceptance of Terms
          </h2>
          <p>
            By accessing or using the Ethereal Finds website (the "Service"), operated by Ethereal Finds Inc. ("us", "we", or "our"), you agree to be bound by these Terms & Conditions ("Terms"). If you disagree with any part of the terms, then you may not access the Service.
          </p>
        </div>

        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3">2. Accounts</h2>
          <p>
            When you create an account with us, you must provide information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our Service. You are responsible for safeguarding the password that you use to access the Service and for any activities or actions under your password.
          </p>
        </div>
        
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3">3. Products or Services</h2>
           <p>
            Certain products or services may be available exclusively online through the website. These products or services may have limited quantities and are subject to return or exchange only according to our Return Policy. We have made every effort to display as accurately as possible the colors and images of our products. We cannot guarantee that your computer monitor's display of any color will be accurate.
          </p>
           <p className="mt-2">
            We reserve the right, but are not obligated, to limit the sales of our products or Services to any person, geographic region or jurisdiction. We may exercise this right on a case-by-case basis. We reserve the right to limit the quantities of any products or services that we offer. All descriptions of products or product pricing are subject to change at any time without notice, at our sole discretion.
          </p>
        </div>

        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3">4. Intellectual Property</h2>
          <p>
            The Service and its original content, features, and functionality are and will remain the exclusive property of Ethereal Finds Inc. and its licensors. The Service is protected by copyright, trademark, and other laws of both Saudi Arabia, UAE, and foreign countries. Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of Ethereal Finds Inc.
          </p>
        </div>
        
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3 flex items-center">
           <AlertTriangle className="mr-3 h-6 w-6" /> 5. Limitation of Liability
          </h2>
          <p>
            In no event shall Ethereal Finds Inc., nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or inability to access or use the Service.
          </p>
        </div>

        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3">6. Governing Law</h2>
          <p>
            These Terms shall be governed and construed in accordance with the laws of Saudi Arabia and/or the United Arab Emirates, without regard to its conflict of law provisions.
          </p>
        </div>
        
        <div className="p-6 bg-card border rounded-lg shadow-sm">
          <h2 className="text-2xl font-headline font-semibold text-primary mb-3">7. Changes to Terms</h2>
          <p>
            We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
          </p>
        </div>
      </section>
      
      <section className="text-center mt-12">
        <p className="text-muted-foreground">
          If you have any questions about these Terms, please <a href="/contact" className="text-primary hover:underline">contact us</a>.
        </p>
      </section>
    </div>
  );
}
