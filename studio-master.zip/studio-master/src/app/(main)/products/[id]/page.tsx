
"use client";

import React, { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { getProductById, mockProducts } from '@/lib/mock-data';
import type { Product } from '@/lib/mock-data';
import { ProductImageCarousel } from '@/components/product-image-carousel';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Star, ShoppingCart, Heart, MessageCircle, Edit3, ThumbsUp, ThumbsDown, Share2 } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { ProductCard } from '@/components/product-card';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input"; // Added Input import
import Link from 'next/link'; // Added Link import
import { useLocalization } from '@/contexts/localization-context';
import { Card, CardContent } from "@/components/ui/card"; // Added Card and CardContent


const ProductDetailPage = () => {
  const params = useParams();
  const productId = typeof params.id === 'string' ? params.id : '';
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(undefined);
  const [selectedSize, setSelectedSize] = useState<string | undefined>(undefined);
  const [quantity, setQuantity] = useState(1);
  const { toast } = useToast();
  const { formatPrice, language, currency } = useLocalization();

  useEffect(() => {
    if (productId) {
      const fetchedProduct = getProductById(productId);
      if (fetchedProduct) {
        setProduct(fetchedProduct);
        if (fetchedProduct.colors && fetchedProduct.colors.length > 0) {
          setSelectedColor(fetchedProduct.colors[0]);
        }
        if (fetchedProduct.sizes && fetchedProduct.sizes.length > 0) {
          setSelectedSize(fetchedProduct.sizes[0]);
        }
      }
      setLoading(false);
    }
  }, [productId]);

  const handleAddToCart = () => {
    if (!product) return;
    // Actual cart logic would go here
    toast({
      title: "Added to Cart!",
      description: `${quantity} x ${product.name} ${selectedColor ? `(${selectedColor})` : ''} ${selectedSize ? `(${selectedSize})` : ''} added.`,
    });
  };

  const handleAddToWishlist = () => {
    if (!product) return;
    // Actual wishlist logic would go here
    toast({
      title: "Added to Wishlist!",
      description: `${product.name} has been added to your wishlist.`,
    });
  };
  
  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Star
          key={i}
          className={`h-5 w-5 ${i <= Math.round(rating) ? 'fill-accent text-accent' : 'text-muted-foreground'}`}
        />
      );
    }
    return stars;
  };
  
  // Mock reviews data
  const mockReviews = [
    { id: 'r1', author: 'Alice M.', avatar: 'https://placehold.co/40x40.png?text=AM', rating: 5, date: '2 weeks ago', text: 'Absolutely stunning product! The quality is amazing and it looks even better in person.', likes: 15, dislikes: 0 },
    { id: 'r2', author: 'Bob K.', avatar: 'https://placehold.co/40x40.png?text=BK', rating: 4, date: '1 month ago', text: 'Great product, very happy with my purchase. Shipping was fast too.', likes: 8, dislikes: 1 },
    { id: 'r3', author: 'Charlie P.', avatar: 'https://placehold.co/40x40.png?text=CP', rating: 5, date: '3 days ago', text: 'Exceeded my expectations! Will definitely buy from this store again.', likes: 22, dislikes: 0 },
  ];


  if (loading) {
    return (
       <div className="container mx-auto py-8">
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* Image Skeleton */}
          <div className="aspect-[4/5] bg-muted rounded-lg animate-pulse"></div>
          {/* Details Skeleton */}
          <div className="space-y-6">
            <div className="h-10 bg-muted rounded w-3/4 animate-pulse"></div>
            <div className="flex items-center space-x-2">
              <div className="h-6 w-28 bg-muted rounded animate-pulse"></div>
              <div className="h-4 w-20 bg-muted rounded animate-pulse"></div>
            </div>
            <div className="h-8 bg-muted rounded w-1/4 animate-pulse"></div>
            <div className="h-20 bg-muted rounded animate-pulse"></div>
            <div className="h-12 bg-muted rounded w-full animate-pulse"></div>
            <div className="h-10 bg-muted rounded w-1/2 animate-pulse"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return <div className="text-center py-20">
      <h2 className="text-2xl font-headline">Product not found</h2>
      <p className="text-muted-foreground">The product you are looking for does not exist or may have been removed.</p>
      <Button asChild className="mt-4"><Link href="/products">Back to Products</Link></Button>
      </div>;
  }

  const relatedProducts = mockProducts.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  return (
    <div className="container mx-auto py-8">
      <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-start">
        <ProductImageCarousel images={product.images} productName={product.name} />
        
        <div className="space-y-6">
          <h1 className="text-3xl lg:text-4xl font-headline font-bold text-primary">{product.name}</h1>
          
          <div className="flex items-center space-x-2">
            <div className="flex">{renderStars(product.rating)}</div>
            <span className="text-sm text-muted-foreground">({product.reviewsCount} reviews)</span>
            <Separator orientation="vertical" className="h-5" />
            <Badge variant={product.stock > 0 ? "secondary" : "destructive"} className="text-xs py-1 px-2">
              {product.stock > 0 ? `${product.stock} in stock` : "Out of Stock"}
            </Badge>
          </div>

          <p className="text-3xl font-semibold text-accent">{formatPrice(product.price)}</p>
          
          <p className="text-foreground/80 leading-relaxed">{product.description}</p>

          {product.colors && product.colors.length > 0 && (
            <div className="space-y-2">
              <Label htmlFor="color-select" className="text-sm font-medium">Color:</Label>
              <Select value={selectedColor} onValueChange={setSelectedColor}>
                <SelectTrigger id="color-select" className="w-full md:w-[200px]">
                  <SelectValue placeholder="Select a color" />
                </SelectTrigger>
                <SelectContent>
                  {product.colors.map(color => (
                    <SelectItem key={color} value={color}>{color}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {product.sizes && product.sizes.length > 0 && (
             <div className="space-y-2">
              <Label htmlFor="size-select" className="text-sm font-medium">Size:</Label>
              <Select value={selectedSize} onValueChange={setSelectedSize}>
                <SelectTrigger id="size-select" className="w-full md:w-[200px]">
                  <SelectValue placeholder="Select a size" />
                </SelectTrigger>
                <SelectContent>
                  {product.sizes.map(size => (
                    <SelectItem key={size} value={size}>{size}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          
          <div className="flex items-center space-x-3">
            <Label htmlFor="quantity" className="text-sm font-medium">Quantity:</Label>
            <Input 
              type="number" 
              id="quantity"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
              min="1"
              max={product.stock > 0 ? product.stock : 1}
              className="w-20 h-10 text-center"
              disabled={product.stock === 0}
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Button 
              size="lg" 
              className="flex-1" 
              onClick={handleAddToCart}
              disabled={product.stock === 0}
            >
              <ShoppingCart className="mr-2 h-5 w-5" /> {product.stock > 0 ? "Add to Cart" : "Out of Stock"}
            </Button>
            <Button size="lg" variant="outline" className="flex-1" onClick={handleAddToWishlist}>
              <Heart className="mr-2 h-5 w-5" /> Add to Wishlist
            </Button>
          </div>
          
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Share2 className="h-4 w-4" />
            <span>Share this product</span>
            {/* Add social share icons/buttons here */}
          </div>

          <Accordion type="single" collapsible className="w-full">
            {product.specifications && (
              <AccordionItem value="specifications">
                <AccordionTrigger className="text-base font-semibold">Specifications</AccordionTrigger>
                <AccordionContent>
                  <ul className="list-disc list-inside space-y-1 text-sm text-foreground/80">
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <li key={key}><strong>{key}:</strong> {value}</li>
                    ))}
                  </ul>
                </AccordionContent>
              </AccordionItem>
            )}
            {product.benefits && product.benefits.length > 0 && (
              <AccordionItem value="benefits">
                <AccordionTrigger className="text-base font-semibold">Benefits</AccordionTrigger>
                <AccordionContent>
                  <ul className="list-disc list-inside space-y-1 text-sm text-foreground/80">
                    {product.benefits.map((benefit, index) => (
                      <li key={index}>{benefit}</li>
                    ))}
                  </ul>
                </AccordionContent>
              </AccordionItem>
            )}
            {product.videoUrl && (
               <AccordionItem value="video">
                <AccordionTrigger className="text-base font-semibold">Product Video</AccordionTrigger>
                <AccordionContent>
                  <div className="aspect-video w-full">
                    <video controls src={product.videoUrl} className="rounded-md w-full h-full" poster={product.images[0]}>
                      Your browser does not support the video tag.
                    </video>
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}
          </Accordion>
        </div>
      </div>

      <Separator className="my-12" />

      {/* Reviews Section */}
      <section className="space-y-8">
        <h2 className="text-2xl font-headline font-semibold">Customer Reviews ({product.reviewsCount})</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {mockReviews.map(review => (
            <Card key={review.id}>
              <CardContent className="p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarImage src={review.avatar} alt={review.author} data-ai-hint="avatar person" />
                      <AvatarFallback>{review.author.substring(0,2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold text-sm">{review.author}</p>
                      <p className="text-xs text-muted-foreground">{review.date}</p>
                    </div>
                  </div>
                  <div className="flex">{renderStars(review.rating)}</div>
                </div>
                <p className="text-sm text-foreground/90 leading-relaxed">{review.text}</p>
                <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                  <Button variant="ghost" size="sm" className="p-1 h-auto"><ThumbsUp className="h-4 w-4 mr-1" /> ({review.likes})</Button>
                  <Button variant="ghost" size="sm" className="p-1 h-auto"><ThumbsDown className="h-4 w-4 mr-1" /> ({review.dislikes})</Button>
                  <Button variant="ghost" size="sm" className="p-1 h-auto"><MessageCircle className="h-4 w-4 mr-1" /> Reply</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="mt-8">
          <h3 className="text-xl font-headline font-semibold mb-4">Leave a Review</h3>
          <form className="space-y-4">
            <div>
              <Label className="mb-1 block text-sm">Your Rating</Label>
              {/* Basic star rating input - can be improved with a dedicated component */}
              <div className="flex space-x-1">
                {[1,2,3,4,5].map(star => <Button key={star} variant="ghost" size="icon" aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}><Star className="h-5 w-5 text-muted-foreground hover:text-accent"/></Button>)}
              </div>
            </div>
            <div>
              <Label htmlFor="review-text" className="mb-1 block text-sm">Your Review</Label>
              <Textarea id="review-text" placeholder="Share your thoughts about the product..." rows={4} />
            </div>
            <Button type="submit"><Edit3 className="mr-2 h-4 w-4" /> Submit Review</Button>
          </form>
        </div>
      </section>

      <Separator className="my-12" />

      {/* Related Products Section */}
      {relatedProducts.length > 0 && (
        <section>
          <h2 className="text-2xl font-headline font-semibold mb-6">You Might Also Like</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((relatedProduct) => (
              <ProductCard key={relatedProduct.id} product={relatedProduct} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

export default ProductDetailPage;

    