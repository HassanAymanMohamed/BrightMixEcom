
"use client";

import React, { useState, useEffect, useMemo } from 'react';
import { ProductCard } from '@/components/product-card';
import { mockProducts, categories as allCategories, brands as allBrands } from '@/lib/mock-data';
import type { Product } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Search, Filter, X } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useIsMobile } from '@/hooks/use-mobile';
import { useSearchParams } from 'next/navigation';


const PriceRangeSlider = ({ value, onChange }: { value: [number, number], onChange: (value: [number, number]) => void }) => {
  const [localValue, setLocalValue] = useState(value);

  useEffect(() => {
    setLocalValue(value);
  }, [value]);

  return (
    <div className="space-y-2">
       <div className="flex justify-between text-sm text-muted-foreground">
        <span>${localValue[0]}</span>
        <span>${localValue[1]}</span>
      </div>
      <Slider
        min={0}
        max={500} // Adjust max based on your product prices
        step={10}
        value={localValue}
        onValueChange={setLocalValue}
        onValueCommit={onChange} // Use onValueCommit to avoid too many re-renders while dragging
        className="[&_[role=slider]]:h-4 [&_[role=slider]]:w-4"
        aria-label="Price range"
      />
    </div>
  );
};


export default function ProductsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500]);
  const [selectedRating, setSelectedRating] = useState<number>(0);
  const [sortBy, setSortBy] = useState('default');
  const [mounted, setMounted] = useState(false);
  const isMobile = useIsMobile();
  const [isFiltersOpenMobile, setIsFiltersOpenMobile] = useState(false);
  const searchParams = useSearchParams();

  useEffect(() => {
    setMounted(true);
    const querySearchTerm = searchParams.get('search');
    if (querySearchTerm !== null) { // If 'search' param exists in URL (even if empty string)
      setSearchTerm(querySearchTerm);
    }
  }, [searchParams]);

  const handleCategoryChange = (category: string) => {
    setSelectedCategories(prev =>
      prev.includes(category) ? prev.filter(c => c !== category) : [...prev, category]
    );
  };

  const handleBrandChange = (brand: string) => {
    setSelectedBrands(prev =>
      prev.includes(brand) ? prev.filter(b => b !== brand) : [...prev, brand]
    );
  };
  
  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategories([]);
    setSelectedBrands([]);
    setPriceRange([0, 500]);
    setSelectedRating(0);
    setSortBy('default');
  };

  const filteredProducts = useMemo(() => {
    let products = mockProducts;

    if (searchTerm) {
      products = products.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    if (selectedCategories.length > 0) {
      products = products.filter(p => selectedCategories.includes(p.category));
    }
    if (selectedBrands.length > 0) {
      products = products.filter(p => selectedBrands.includes(p.brand));
    }
    products = products.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);
    if (selectedRating > 0) {
      products = products.filter(p => Math.round(p.rating) >= selectedRating);
    }

    switch (sortBy) {
      case 'price_asc':
        products.sort((a, b) => a.price - b.price);
        break;
      case 'price_desc':
        products.sort((a, b) => b.price - a.price);
        break;
      case 'rating_desc':
        products.sort((a, b) => b.rating - a.rating);
        break;
      // Add more sort options if needed
    }
    return products;
  }, [searchTerm, selectedCategories, selectedBrands, priceRange, selectedRating, sortBy]);

  const filtersContent = (
    <div className="space-y-6">
       <Button onClick={clearFilters} variant="outline" className="w-full">
          <X className="mr-2 h-4 w-4" /> Clear All Filters
        </Button>
      <Accordion type="multiple" defaultValue={['category', 'brand', 'price']} className="w-full">
        <AccordionItem value="category">
          <AccordionTrigger className="text-base font-semibold">Category</AccordionTrigger>
          <AccordionContent className="space-y-2 pt-2">
            {allCategories.map(category => (
              <div key={category} className="flex items-center space-x-2">
                <Checkbox
                  id={`cat-${category}`}
                  checked={selectedCategories.includes(category)}
                  onCheckedChange={() => handleCategoryChange(category)}
                />
                <Label htmlFor={`cat-${category}`} className="font-normal text-sm">{category}</Label>
              </div>
            ))}
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="brand">
          <AccordionTrigger className="text-base font-semibold">Brand</AccordionTrigger>
          <AccordionContent className="space-y-2 pt-2">
            {allBrands.map(brand => (
              <div key={brand} className="flex items-center space-x-2">
                <Checkbox
                  id={`brand-${brand}`}
                  checked={selectedBrands.includes(brand)}
                  onCheckedChange={() => handleBrandChange(brand)}
                />
                <Label htmlFor={`brand-${brand}`} className="font-normal text-sm">{brand}</Label>
              </div>
            ))}
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="price">
          <AccordionTrigger className="text-base font-semibold">Price Range</AccordionTrigger>
          <AccordionContent className="pt-4">
            <PriceRangeSlider value={priceRange} onChange={setPriceRange} />
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="rating">
          <AccordionTrigger className="text-base font-semibold">Rating</AccordionTrigger>
          <AccordionContent className="space-y-2 pt-2">
            {[5, 4, 3, 2, 1].map(rating => (
              <div key={rating} className="flex items-center space-x-2">
                <Checkbox
                  id={`rating-${rating}`}
                  checked={selectedRating === rating}
                  onCheckedChange={() => setSelectedRating(prev => prev === rating ? 0 : rating)}
                />
                <Label htmlFor={`rating-${rating}`} className="font-normal text-sm">
                  {Array(rating).fill(null).map((_, i) => <span key={i}>&#9733;</span>)} & Up
                </Label>
              </div>
            ))}
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
  
  if (!mounted) {
     return (
      <div className="flex flex-col lg:flex-row gap-8">
        <aside className="w-full lg:w-1/4 space-y-6">
          <div className="h-10 bg-muted rounded animate-pulse w-full"></div>
          {[...Array(4)].map((_, i) => (
            <div key={i} className="p-4 border rounded-lg bg-card">
              <div className="h-6 bg-muted rounded animate-pulse w-1/2 mb-4"></div>
              {[...Array(3)].map((_, j) => (
                <div key={j} className="flex items-center space-x-2 mb-2">
                  <div className="h-4 w-4 bg-muted rounded animate-pulse"></div>
                  <div className="h-4 bg-muted rounded animate-pulse w-3/4"></div>
                </div>
              ))}
            </div>
          ))}
        </aside>
        <main className="w-full lg:w-3/4">
           <div className="h-10 bg-muted rounded animate-pulse w-full mb-6"></div>
           <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="rounded-lg border bg-card p-4 space-y-3">
                <div className="aspect-[3/4] bg-muted rounded animate-pulse"></div>
                <div className="h-5 bg-muted rounded animate-pulse w-3/4"></div>
                <div className="h-4 bg-muted rounded animate-pulse w-1/2"></div>
                <div className="h-8 bg-muted rounded animate-pulse w-full"></div>
              </div>
            ))}
          </div>
        </main>
      </div>
    );
  }


  return (
    <div>
      <header className="mb-8">
        <h1 className="text-4xl font-headline font-bold text-primary mb-2">Our Collection</h1>
        <p className="text-lg text-muted-foreground">Browse through our curated selection of ethereal finds.</p>
      </header>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters Sidebar - Desktop */}
        {!isMobile && (
          <aside className="w-full lg:w-1/4 space-y-6 lg:sticky lg:top-24 self-start h-fit max-h-[calc(100vh-8rem)] overflow-y-auto pr-4 pb-8 scrollbar-thin scrollbar-thumb-muted scrollbar-track-transparent">
            <h2 className="text-2xl font-headline font-semibold">Filters</h2>
            {filtersContent}
          </aside>
        )}

        {/* Products Grid */}
        <main className="w-full lg:w-3/4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
            <div className="relative w-full md:max-w-sm">
              <Input
                type="search"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 h-10 text-sm"
                aria-label="Search products"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>

            <div className="flex items-center gap-4 w-full md:w-auto">
              {/* Filters Trigger - Mobile */}
              {isMobile && (
                <Sheet open={isFiltersOpenMobile} onOpenChange={setIsFiltersOpenMobile}>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="w-full md:w-auto">
                      <Filter className="mr-2 h-4 w-4" /> Filters
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-[300px] sm:w-[400px] p-6 overflow-y-auto">
                     <div className="flex justify-between items-center mb-4">
                        <h2 className="text-2xl font-headline font-semibold">Filters</h2>
                        <Button variant="ghost" size="icon" onClick={() => setIsFiltersOpenMobile(false)}>
                            <X className="h-5 w-5" />
                        </Button>
                     </div>
                    {filtersContent}
                  </SheetContent>
                </Sheet>
              )}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full md:w-[180px] h-10 text-sm" aria-label="Sort by">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Default</SelectItem>
                  <SelectItem value="price_asc">Price: Low to High</SelectItem>
                  <SelectItem value="price_desc">Price: High to Low</SelectItem>
                  <SelectItem value="rating_desc">Rating: High to Low</SelectItem>
                  {/* Add more sort options here */}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Search className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-2xl font-headline font-semibold mb-2">No Products Found</h3>
              <p className="text-muted-foreground mb-6">Try adjusting your filters or search terms.</p>
              <Button onClick={clearFilters} variant="outline">Clear Filters</Button>
            </div>
          )}

          {/* Pagination Placeholder */}
          {filteredProducts.length > 10 && ( // Show pagination if more than 10 products
             <div className="mt-12 flex justify-center">
              <Button variant="outline" className="mr-2">Previous</Button>
              <Button variant="outline">Next</Button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
