
"use client";

import React, { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { CreditCard, Gift, Home, Lock, Package, ShoppingBag, Truck, User } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useLocalization } from '@/contexts/localization-context';
import { Badge } from '@/components/ui/badge'; // Added Badge import
import Image from 'next/image'; // Added Image import

// Mock cart items for summary - in real app, this would come from context/state
const mockCartSummaryItems = [
  { id: '1', name: 'Celestial Silk Scarf', price: 89.99, quantity: 1, image: 'https://placehold.co/100x100.png?a=1' },
  { id: '2', name: 'Mystic Moonstone Ring', price: 120.00, quantity: 1, image: 'https://placehold.co/100x100.png?b=1' },
];

// Base prices in USD
const subtotalUSD = mockCartSummaryItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
const shippingUSD = 5.00;
const taxUSD = subtotalUSD * 0.08;
const totalUSD = subtotalUSD + shippingUSD + taxUSD;


export default function CheckoutPage() {
  const [isGuestCheckout, setIsGuestCheckout] = useState(false);
  const { toast } = useToast();
  const { formatPrice, language, currency } = useLocalization();
  
  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    // Placeholder for order placement logic
    toast({
      title: "Order Placed!",
      description: "Thank you for your purchase. Your order is being processed.",
    });
    // Redirect to order confirmation page or clear cart
  };


  return (
    <div className="container mx-auto py-8">
      <header className="mb-10 text-center">
        <h1 className="text-4xl font-headline font-bold text-primary">Checkout</h1>
        <p className="text-lg text-muted-foreground mt-2">Complete your purchase securely.</p>
      </header>

      <div className="lg:flex lg:gap-12 items-start">
        {/* Checkout Form Section */}
        <div className="lg:w-2/3 mb-8 lg:mb-0">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl font-headline flex items-center">
                <User className="mr-3 h-6 w-6 text-primary" /> Customer Information
              </CardTitle>
              {!isGuestCheckout && (
                <CardDescription>
                  Already have an account? <Link href="/login" className="text-primary hover:underline">Log In</Link> for a faster checkout.
                </CardDescription>
              )}
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePlaceOrder} className="space-y-6">
                {!isGuestCheckout ? (
                  <div className="flex items-center space-x-2 mb-6">
                    <Checkbox id="guest-checkout" checked={isGuestCheckout} onCheckedChange={(checked) => setIsGuestCheckout(checked === true)} />
                    <Label htmlFor="guest-checkout" className="text-sm">Checkout as Guest</Label>
                  </div>
                ) : (
                   <p className="text-sm text-muted-foreground">You are checking out as a guest. <Button variant="link" className="p-0 h-auto text-primary" onClick={() => setIsGuestCheckout(false)}>Log In or Create Account?</Button></p>
                )}

                {/* Email for guest or logged in user */}
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input id="email" type="email" placeholder="you@example.com" required className="mt-1" />
                </div>

                {/* Shipping Address */}
                <section className="space-y-4 pt-4 border-t">
                  <h3 className="text-lg font-semibold flex items-center"><Home className="mr-2 h-5 w-5 text-primary"/>Shipping Address</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="first-name">First Name</Label>
                      <Input id="first-name" placeholder="John" required className="mt-1"/>
                    </div>
                    <div>
                      <Label htmlFor="last-name">Last Name</Label>
                      <Input id="last-name" placeholder="Doe" required className="mt-1"/>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input id="address" placeholder="123 Main St" required className="mt-1"/>
                  </div>
                  <div>
                    <Label htmlFor="apartment">Apartment, suite, etc. (optional)</Label>
                    <Input id="apartment" placeholder="Apt 4B" className="mt-1"/>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="city">City</Label>
                      <Input id="city" placeholder="New York" required className="mt-1"/>
                    </div>
                    <div>
                      <Label htmlFor="country">Country</Label>
                      <Input id="country" placeholder="United States" required className="mt-1"/>
                    </div>
                    <div>
                      <Label htmlFor="zip">ZIP / Postal Code</Label>
                      <Input id="zip" placeholder="10001" required className="mt-1"/>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone (for shipping updates)</Label>
                    <Input id="phone" type="tel" placeholder="+1 (555) 123-4567" className="mt-1"/>
                  </div>
                </section>

                {/* Shipping Method */}
                <section className="space-y-4 pt-4 border-t">
                  <h3 className="text-lg font-semibold flex items-center"><Truck className="mr-2 h-5 w-5 text-primary"/>Shipping Method</h3>
                  <div className="p-3 border rounded-md bg-muted/30">
                    <Label className="flex items-center justify-between">
                      <span className="flex items-center">
                        <Checkbox id="std-shipping" checked readOnly className="mr-2"/> Standard Shipping (5-7 business days)
                      </span>
                      <span>{formatPrice(shippingUSD)}</span>
                    </Label>
                  </div>
                </section>

                {/* Payment Method */}
                <section className="space-y-4 pt-4 border-t">
                  <h3 className="text-lg font-semibold flex items-center"><CreditCard className="mr-2 h-5 w-5 text-primary"/>Payment</h3>
                  <p className="text-sm text-muted-foreground">All transactions are secure and encrypted.</p>
                  <Accordion type="single" collapsible defaultValue="card" className="w-full">
                    <AccordionItem value="card">
                      <AccordionTrigger className="font-medium">Credit/Debit Card</AccordionTrigger>
                      <AccordionContent className="space-y-3 pt-2">
                        <div>
                          <Label htmlFor="card-number">Card Number</Label>
                          <Input id="card-number" placeholder="•••• •••• •••• ••••" required className="mt-1"/>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="expiry-date">Expiration Date</Label>
                            <Input id="expiry-date" placeholder="MM / YY" required className="mt-1"/>
                          </div>
                          <div>
                            <Label htmlFor="cvc">CVC</Label>
                            <Input id="cvc" placeholder="•••" required className="mt-1"/>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="apple-pay">
                      <AccordionTrigger className="font-medium">Apple Pay</AccordionTrigger>
                      <AccordionContent className="pt-2">
                        <Button className="w-full bg-black hover:bg-gray-800 text-white">Pay with Apple Pay</Button>
                      </AccordionContent>
                    </AccordionItem>
                     <AccordionItem value="stc-pay">
                      <AccordionTrigger className="font-medium">STC Pay</AccordionTrigger>
                      <AccordionContent className="pt-2">
                        <p className="text-sm text-muted-foreground">Follow instructions on STC Pay app to complete payment.</p>
                        <Button className="w-full mt-2" variant="outline">Pay with STC Pay</Button>
                      </AccordionContent>
                    </AccordionItem>
                    <AccordionItem value="bank-transfer">
                      <AccordionTrigger className="font-medium">Bank Transfer</AccordionTrigger>
                       <AccordionContent className="pt-2">
                        <p className="text-sm text-muted-foreground">Instructions for bank transfer will be provided after placing the order.</p>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </section>

                <Button type="submit" size="lg" className="w-full mt-6 bg-accent hover:bg-accent/90 text-accent-foreground">
                  <Lock className="mr-2 h-5 w-5" /> Place Order Securely
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Order Summary Section */}
        <aside className="lg:w-1/3 lg:sticky lg:top-24">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl font-headline flex items-center"><ShoppingBag className="mr-3 h-6 w-6 text-primary"/>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {mockCartSummaryItems.map(item => (
                <div key={item.id} className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="relative w-16 h-16 rounded-md overflow-hidden border">
                       <Image src={item.image} alt={item.name} width={64} height={64} className="object-cover w-full h-full" data-ai-hint="product thumbnail" />
                       <Badge variant="secondary" className="absolute -top-2 -right-2 rounded-full px-1.5 py-0.5 text-xs">{item.quantity}</Badge>
                    </div>
                    <div>
                      <p className="text-sm font-medium leading-tight">{item.name}</p>
                      <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                    </div>
                  </div>
                  <p className="text-sm font-semibold">{formatPrice(item.price * item.quantity)}</p>
                </div>
              ))}
              <Separator />
              <div className="flex justify-between text-sm">
                <span>Subtotal</span>
                <span>{formatPrice(subtotalUSD)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Shipping</span>
                <span>{formatPrice(shippingUSD)}</span>
              </div>
               <div className="flex justify-between text-sm">
                <span>Taxes</span>
                <span>{formatPrice(taxUSD)}</span>
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-bold text-primary">
                <span>Total</span>
                <span>{formatPrice(totalUSD)}</span>
              </div>
            </CardContent>
             <CardFooter className="flex flex-col gap-2">
                <div className="flex items-center gap-2 w-full">
                    <Input type="text" placeholder="Gift card or discount code" className="h-9 text-sm flex-grow" aria-label="Discount code"/>
                    <Button variant="outline" size="sm" className="h-9 shrink-0">Apply</Button>
                </div>
                <p className="text-xs text-muted-foreground text-center mt-2">
                  By placing your order, you agree to our <Link href="/terms" className="underline hover:text-primary">Terms & Conditions</Link>.
                </p>
            </CardFooter>
          </Card>
           <div className="mt-6 p-4 border rounded-lg bg-muted/30 flex items-start gap-3 text-sm">
            <Package className="h-8 w-8 text-primary mt-1 shrink-0"/>
            <div>
              <h4 className="font-semibold">Estimated Delivery</h4>
              <p className="text-muted-foreground">Calculated after shipping address is entered. Typically 5-7 business days.</p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
