"use client";

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { HelpCircle } from 'lucide-react';

const faqItems = [
  {
    id: "faq1",
    question: "What payment methods do you accept?",
    answer: "We accept various payment methods including major credit/debit cards (Visa, Mastercard, Amex), Apple Pay, STC Pay, and bank transfers for select regions. All transactions are secure and encrypted."
  },
  {
    id: "faq2",
    question: "What is your return policy?",
    answer: "We offer a 14-day return policy for most items in new and unused condition with original packaging. Some exclusions may apply (e.g., custom items, final sale). Please visit our Shipping & Returns page for full details."
  },
  {
    id: "faq3",
    question: "How can I track my order?",
    answer: "Once your order is shipped, you will receive an email with a tracking number and a link to the carrier's website. You can also track your order status from your Account Dashboard under 'Orders'."
  },
  {
    id: "faq4",
    question: "Do you ship internationally?",
    answer: "Yes, we ship to many countries worldwide! Shipping costs and delivery times vary depending on the destination. You can get a shipping estimate at checkout before completing your purchase."
  },
  {
    id: "faq5",
    question: "How do I use a discount code?",
    answer: "You can enter your discount code or gift card number in the designated field during the checkout process. The discount will be applied to your order total before payment."
  },
  {
    id: "faq6",
    question: "What if an item is out of stock?",
    answer: "If an item is out of stock, you can often sign up to be notified when it's back in stock. We also recommend checking our 'New Arrivals' section or similar products."
  },
];

export default function FAQPage() {
  return (
    <div className="py-8">
      <section className="text-center mb-16">
        <HelpCircle className="mx-auto h-16 w-16 text-primary mb-6 opacity-80" />
        <h1 className="text-5xl font-headline font-bold text-primary mb-4">Frequently Asked Questions</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Find answers to common questions about Ethereal Finds, our products, and services.
        </p>
      </section>

      <section className="max-w-3xl mx-auto">
        <Accordion type="single" collapsible className="w-full space-y-3">
          {faqItems.map((item) => (
            <AccordionItem key={item.id} value={item.id} className="border rounded-lg bg-card shadow-sm">
              <AccordionTrigger className="px-6 py-4 text-left text-lg font-semibold hover:no-underline">
                {item.question}
              </AccordionTrigger>
              <AccordionContent className="px-6 pb-4 text-base text-muted-foreground leading-relaxed">
                {item.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      <section className="text-center mt-16">
        <h2 className="text-2xl font-headline font-semibold mb-4">Can't find an answer?</h2>
        <p className="text-muted-foreground mb-6">
          If you have other questions, please don't hesitate to <a href="/contact" className="text-primary hover:underline