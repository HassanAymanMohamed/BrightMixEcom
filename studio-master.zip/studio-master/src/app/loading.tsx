// src/app/loading.tsx
// This component is automatically used by Next.js as a fallback for page navigations
// when wrapped in a Suspense boundary.

export default function Loading() {
  return (
    <div className="fixed top-0 left-0 right-0 h-[3px] z-[9999] bg-transparent overflow-hidden">
      <div
        className="h-full animate-top-loader-bar"
        style={{
          background: `linear-gradient(to right, hsl(var(--primary)), hsl(var(--accent)))`,
        }}
        role="progressbar"
        aria-label="Loading page content"
        aria-valuetext="Loading..."
      />
    </div>
  );
}
