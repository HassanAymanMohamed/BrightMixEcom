"use client";

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { MoreHorizontal, PlusCircle, Edit, Trash2, Search, Filter, Image as ImageIcon, Eye } from "lucide-react";
import Link from 'next/link';
import Image from 'next/image';
import { mockProducts } from '@/lib/mock-data'; // Using mock products
import type { Product } from '@/lib/mock-data';

export default function AdminProductsPage() {
  const [products, setProducts]