import { config } from 'dotenv';
config();

import '@/ai/flows/ai-chatbot-support.ts';
import '@/ai/flows/product-recommendations.ts';