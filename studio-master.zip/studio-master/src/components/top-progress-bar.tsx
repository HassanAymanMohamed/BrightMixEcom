// This component is no longer needed as src/app/loading.tsx and CSS animations handle page navigation loading.
// You can safely delete this file if it's not used elsewhere.
// If it was imported in src/app/layout.tsx, that import has been removed.

// "use client";

// import React, { useState, useEffect, useRef } from 'react';
// import { usePathname, useSearchParams } from 'next/navigation';

// export function TopProgressBar() {
//   const [progress, setProgress] = useState(0);
//   const [isVisible, setIsVisible] = useState(false);
//   const pathname = usePathname();
//   const searchParams = useSearchParams();
  
//   const advanceProgressTimerRef = useRef<NodeJS.Timeout | null>(null);
//   const finishLoadingTimerRef = useRef<NodeJS.Timeout | null>(null);
//   const resetProgressTimerRef = useRef<NodeJS.Timeout | null>(null);

//   const clearAllTimers = () => {
//     if (advanceProgressTimerRef.current) clearTimeout(advanceProgressTimerRef.current);
//     if (finishLoadingTimerRef.current) clearTimeout(finishLoadingTimerRef.current);
//     if (resetProgressTimerRef.current) clearTimeout(resetProgressTimerRef.current);
//   };

//   useEffect(() => {
//     clearAllTimers(); 

//     setIsVisible(true);
//     setProgress(10); 

//     let currentProgress = 10;
//     const advance = () => {
//       if (currentProgress < 90) {
//         currentProgress += Math.max(2, Math.floor(Math.random() * 8)); 
//         if (currentProgress > 90) currentProgress = 90;
//         setProgress(currentProgress);
//         advanceProgressTimerRef.current = setTimeout(advance, 150 + Math.random() * 150); 
//       }
//     };
    
//     advanceProgressTimerRef.current = setTimeout(advance, 50); 

//     finishLoadingTimerRef.current = setTimeout(() => {
//       if (advanceProgressTimerRef.current) clearTimeout(advanceProgressTimerRef.current); 
//       setProgress(100); 
      
//       finishLoadingTimerRef.current = setTimeout(() => {
//         setIsVisible(false);
//         resetProgressTimerRef.current = setTimeout(() => {
//             setProgress(0); 
//         }, 350); 
//       }, 300); 
//     }, 1000); 

//     return () => {
//       clearAllTimers();
//     };
//   }, [pathname, searchParams]);

//   return (
//     <div
//       className="fixed top-0 left-0 right-0 h-[3px] z-[9999] transition-opacity duration-300 ease-out"
//       style={{
//         opacity: isVisible ? 1 : 0,
//         pointerEvents: isVisible ? 'auto' : 'none', 
//       }}
//     >
//       <div
//         className="h-full transition-all duration-200 ease-linear" 
//         style={{
//           width: `${progress}%`,
//           background: `linear-gradient(to right, hsl(var(--primary)), hsl(var(--accent)))`,
//         }}
//       />
//     </div>
//   );
// }
