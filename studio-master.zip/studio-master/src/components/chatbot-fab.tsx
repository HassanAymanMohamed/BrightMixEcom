"use client";

import React, { useState, useEffect } from 'react';
import { MessageSquare, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Chatbot } from '@/components/chatbot'; // Import the Chatbot component

export function ChatbotFAB() {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  if (!isMounted) {
    // Render a placeholder or null for SSR to prevent hydration mismatch
    return (
      <div className="fixed bottom-6 right-6 z-[99] md:bottom-10 md:right-10">
         <div className="h-14 w-14 rounded-full bg-muted animate-pulse"></div>
      </div>
    );
  }

  return (
    <>
      <div className="fixed bottom-6 right-6 z-[99] md:bottom-10 md:right-10">
        <Button
          onClick={toggleChat}
          size="icon"
          className="rounded-full w-14 h-14 bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg transition-transform hover:scale-110"
          aria-label={isChatOpen ? "Close chat" : "Open chat"}
        >
          {isChatOpen ? <X className="h-7 w-7" /> : <MessageSquare className="h-7 w-7" />}
        </Button>
      </div>
      {isChatOpen && <Chatbot isOpen={isChatOpen} onClose={toggleChat} />}
    </>
  );
}
