
"use client";

import Link from 'next/link';
import { Facebook, Instagram, Twitter, Youtube } from 'lucide-react';
import React, { useEffect, useState } from 'react';
import { useLocalization } from '@/contexts/localization-context'; 
import { BrightMixLogo } from '@/components/brightmix-logo';


export function Footer() {
  const [mounted, setMounted] = useState(false);
  const [currentYear, setCurrentYear] = useState(() => new Date().getFullYear());
  const { language, translations } = useLocalization(); 
  const t = translations.footer; 
  const tHome = translations.home; 
  const tHeader = translations.header; 


  useEffect(() => {
    setMounted(true);
    setCurrentYear(new Date().getFullYear());
  }, []);

  const displayYear = mounted ? currentYear : new Date().getFullYear(); 

  return (
    <footer role="contentinfo" className="bg-muted/50 border-t mt-auto" suppressHydrationWarning={true}>
      <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="mb-4">
              <BrightMixLogo height="40px" />
            </div>
            <p className="text-sm text-muted-foreground">{t.description}</p>
          </div>
          <div>
            <h4 className="text-md font-headline font-semibold text-foreground mb-4">{t.quickLinks}</h4>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-sm text-muted-foreground hover:text-primary">{t.aboutUs}</Link></li>
              <li><Link href="/contact" className="text-sm text-muted-foreground hover:text-primary">{t.contactUs}</Link></li>
              <li><Link href="/faq" className="text-sm text-muted-foreground hover:text-primary">{t.faq}</Link></li>
              <li><Link href="/shipping-returns" className="text-sm text-muted-foreground hover:text-primary">{t.shippingReturns}</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-md font-headline font-semibold text-foreground mb-4">{t.customerService}</h4>
            <ul className="space-y-2">
              <li><Link href="/account/orders" className="text-sm text-muted-foreground hover:text-primary">{t.orderTracking}</Link></li>
              <li><Link href="/wishlist" className="text-sm text-muted-foreground hover:text-primary">{tHeader.wishlist}</Link></li>
              <li><Link href="/terms" className="text-sm text-muted-foreground hover:text-primary">{t.termsConditions}</Link></li>
              <li><Link href="/privacy" className="text-sm text-muted-foreground hover:text-primary">{t.privacyPolicy}</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-md font-headline font-semibold text-foreground mb-4">{t.followUs}</h4>
            <div className="flex space-x-4">
              <Link href="#" aria-label="Facebook" className="text-muted-foreground hover:text-primary"><Facebook size={20} /></Link>
              <Link href="#" aria-label="Instagram" className="text-muted-foreground hover:text-primary"><Instagram size={20} /></Link>
              <Link href="#" aria-label="Twitter" className="text-muted-foreground hover:text-primary"><Twitter size={20} /></Link>
              <Link href="#" aria-label="Youtube" className="text-muted-foreground hover:text-primary"><Youtube size={20} /></Link>
            </div>
            <h4 className="text-md font-headline font-semibold text-foreground mt-6 mb-2">{t.newsletter}</h4>
            <form className="flex">
              <input type="email" placeholder={t.yourEmail} className="w-full px-3 py-2 text-sm border border-input rounded-l-md focus:outline-none focus:ring-1 focus:ring-primary rtl:rounded-l-none rtl:rounded-r-md" />
              <button type="submit" className="bg-primary text-primary-foreground px-4 py-2 text-sm rounded-r-md hover:bg-primary/90 rtl:rounded-r-none rtl:rounded-l-md">{tHome.subscribe}</button>
            </form>
          </div>
        </div>
        <div className="mt-10 pt-8 border-t border-border text-center">
          <p className="text-sm text-muted-foreground">&copy; {displayYear} {t.copyright}</p>
        </div>
      </div>
    </footer>
  );
}
