
"use client";

import Link from 'next/link';
import { ShoppingCart, Heart, User, Search, Menu, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ThemeToggle } from '@/components/theme-toggle';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from "@/components/ui/dropdown-menu";
import { useLocalization, currencyData } from '@/contexts/localization-context';
import { BrightMixLogo } from '@/components/brightmix-logo';
import { useRouter } from 'next/navigation';

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const { language, setLanguage, currency, setCurrency, translations } = useLocalization(); 
  const t = translations.header; 
  const router = useRouter();
  const [headerSearchValue, setHeaderSearchValue] = useState('');

  const navigationLinks = [
    { href: '/', label: t.home },
    { href: '/products', label: t.products },
    { href: '/about', label: t.about },
    { href: '/contact', label: t.contact },
  ];

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (headerSearchValue.trim()) {
      router.push(`/products?search=${encodeURIComponent(headerSearchValue.trim())}`);
      // setHeaderSearchValue(''); // Optional: Clear after submit
      if (isMobileMenuOpen) {
        setIsMobileMenuOpen(false); // Close mobile menu on search
      }
    }
  };

  if (!mounted) {
    return (
      <header role="banner" className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-20 items-center justify-between">
          <div className="h-9 w-36 bg-muted rounded animate-pulse"></div> {/* Placeholder for logo */}
          <div className="flex items-center space-x-2">
            <div className="h-10 w-10 bg-muted rounded-full animate-pulse"></div> {/* Placeholder for icons */}
            <div className="h-10 w-10 bg-muted rounded-full animate-pulse"></div>
            <div className="h-10 w-10 bg-muted rounded-full animate-pulse"></div>
            <div className="h-10 w-10 bg-muted rounded-full animate-pulse md:hidden"></div> {/* Placeholder for menu icon */}
          </div>
        </div>
      </header>
    );
  }

  return (
    <header role="banner" className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60" suppressHydrationWarning={true}>
      <div className="container mx-auto flex h-20 items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center" aria-label={t.logo}>
          <BrightMixLogo height="36px" />
        </Link>

        <nav className="hidden md:flex items-center space-x-6">
          {navigationLinks.map((link) => (
            <Link key={link.label} href={link.href} className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors">
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center space-x-1 sm:space-x-3">
          <form onSubmit={handleSearchSubmit} className="hidden md:flex items-center space-x-2 border rounded-md p-1">
             <Input
               type="search"
               placeholder={t.searchPlaceholder}
               className="h-8 text-sm border-none focus-visible:ring-0 focus-visible:ring-offset-0 w-40"
               value={headerSearchValue}
               onChange={(e) => setHeaderSearchValue(e.target.value)}
               aria-label={t.searchPlaceholder}
             />
             <Button type="submit" variant="ghost" size="icon" className="h-8 w-8" aria-label="Search">
               <Search className="h-4 w-4" />
             </Button>
          </form>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" aria-label={t.language}>
                <Globe className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>{t.language}</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => setLanguage('en')} disabled={language === 'en'}>{t.english}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLanguage('ar')} disabled={language === 'ar'}>{t.arabic}</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuLabel>{t.currency}</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => setCurrency('USD')} disabled={currency === 'USD'}>{t.usd}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setCurrency('SAR')} disabled={currency === 'SAR'}>{t.sar}</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <ThemeToggle />

          <Link href="/wishlist" aria-label={t.wishlist}>
            <Button variant="ghost" size="icon">
              <Heart className="h-5 w-5" />
            </Button>
          </Link>
          <Link href="/cart" aria-label={t.cart}>
            <Button variant="ghost" size="icon">
              <ShoppingCart className="h-5 w-5" />
            </Button>
          </Link>
          <Link href="/account" aria-label={t.account}>
            <Button variant="ghost" size="icon">
              <User className="h-5 w-5" />
            </Button>
          </Link>

          <div className="md:hidden">
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" aria-label={t.openMenu}>
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-full max-w-xs bg-background p-6">
                <div className="flex flex-col space-y-6">
                  <Link href="/" className="flex items-center mb-6" onClick={() => setIsMobileMenuOpen(false)} aria-label={t.logo}>
                     <BrightMixLogo height="30px"/>
                  </Link>
                  <form onSubmit={handleSearchSubmit} className="relative mb-4">
                    <Input
                      type="search"
                      placeholder={t.searchPlaceholder}
                      className="w-full h-10 text-sm pr-10"
                      value={headerSearchValue}
                      onChange={(e) => setHeaderSearchValue(e.target.value)}
                      aria-label={t.searchPlaceholder}
                    />
                    <Button type="submit" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8" aria-label="Search">
                      <Search className="h-4 w-4" />
                    </Button>
                  </form>
                  {navigationLinks.map((link) => (
                    <Link key={link.label} href={link.href} className="text-lg font-medium text-foreground hover:text-primary transition-colors" onClick={() => setIsMobileMenuOpen(false)}>
                      {link.label}
                    </Link>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
