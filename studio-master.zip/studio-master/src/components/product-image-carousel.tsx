
"use client";

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ProductImageCarouselProps {
  images: string[];
  productName: string;
}

export function ProductImageCarousel({ images, productName }: ProductImageCarouselProps) {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [mainImageLoaded, setMainImageLoaded] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const selectImage = (index: number) => {
    setMainImageLoaded(false);
    setSelectedIndex(index);
  };

  const nextImage = () => {
    setMainImageLoaded(false);
    setSelectedIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  const prevImage = () => {
    setMainImageLoaded(false);
    setSelectedIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
  };

  if (!isMounted || images.length === 0) {
    return (
      <div className="flex flex-col items-center">
        <div className="relative w-full aspect-[4/5] bg-muted rounded-lg animate-pulse mb-4"></div>
        <div className="flex space-x-2">
          {[...Array(Math.min(images.length, 4) || 1)].map((_, i) => (
            <div key={i} className="w-20 h-20 bg-muted rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }


  return (
    <div className="flex flex-col items-center w-full">
      <div className="relative w-full aspect-[4/5] overflow-hidden rounded-lg shadow-md mb-4">
        {!mainImageLoaded && (
            <div className="absolute inset-0 bg-muted animate-pulse z-10"></div>
        )}
        <Image
          key={images[selectedIndex]} // Force re-render on image change for loading state
          src={images[selectedIndex]}
          alt={`${productName} - Image ${selectedIndex + 1}`}
          fill
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          className={cn(
            "object-contain transition-opacity duration-300",
            mainImageLoaded ? "opacity-100" : "opacity-0"
          )}
          onLoad={() => setMainImageLoaded(true)}
          priority={selectedIndex === 0} // Prioritize loading the first image
          data-ai-hint="product detail"
        />
        {images.length > 1 && (
          <>
            <Button
              variant="ghost"
              size="icon"
              onClick={prevImage}
              className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-background/50 hover:bg-background/80 text-foreground"
              aria-label="Previous image"
            >
              <ChevronLeft className="h-6 w-6" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={nextImage}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-background/50 hover:bg-background/80 text-foreground"
              aria-label="Next image"
            >
              <ChevronRight className="h-6 w-6" />
            </Button>
          </>
        )}
      </div>
      {images.length > 1 && (
        <div className="flex space-x-2 overflow-x-auto py-2 scrollbar-thin scrollbar-thumb-muted-foreground/50 scrollbar-track-transparent">
          {images.map((src, index) => (
            <button
              key={index}
              onClick={() => selectImage(index)}
              className={cn(
                "relative w-20 h-20 rounded-md overflow-hidden border-2 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
                selectedIndex === index ? 'border-primary' : 'border-transparent hover:border-muted-foreground/50'
              )}
              aria-label={`View image ${index + 1} of ${productName}`}
            >
              <Image
                src={src}
                alt={`${productName} - Thumbnail ${index + 1}`}
                fill
                sizes="80px"
                className="object-cover"
                data-ai-hint="product thumbnail"
              />
              {selectedIndex === index && <div className="absolute inset-0 bg-primary/30"></div>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
