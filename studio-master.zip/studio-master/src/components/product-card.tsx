
"use client";

import Image from 'next/image';
import Link from 'next/link';
import type { Product } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, ShoppingCart, Star, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useLocalization } from '@/contexts/localization-context';
import React, { useState } from 'react';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { toast } = useToast();
  const { formatPrice } = useLocalization();
  const [isAddingToCart, setIsAddingToCart] = useState(false);
  const [isAddingToWishlist, setIsAddingToWishlist] = useState(false);


  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    setIsAddingToCart(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    setIsAddingToCart(false);
    toast({
      title: "Added to Cart!",
      description: `${product.name} has been added to your cart.`,
    });
  };

  const handleAddToWishlist = async (e: React.MouseEvent) => {
    e.preventDefault();
    setIsAddingToWishlist(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsAddingToWishlist(false);
    toast({
      title: "Added to Wishlist!",
      description: `${product.name} has been added to your wishlist.`,
    });
  };

  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <Star
          key={i}
          className={`h-4 w-4 ${i <= Math.round(rating) ? 'fill-accent text-accent' : 'text-muted-foreground'}`}
        />
      );
    }
    return stars;
  };


  return (
    <>
      <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 h-full flex flex-col group">
        <CardHeader className="p-0">
          <Link href={`/products/${product.id}`} aria-label={`View details for ${product.name}`}>
            <div className="aspect-[3/4] relative overflow-hidden">
              <Image
                src={product.images[0]}
                alt={product.name}
                fill
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                className="object-cover group-hover:scale-105 transition-transform duration-300"
                data-ai-hint="product fashion"
              />
            </div>
          </Link>
        </CardHeader>
        <CardContent className="p-4 flex-grow">
          <Link href={`/products/${product.id}`} className="hover:no-underline">
            <CardTitle className="text-lg font-headline mb-1 leading-tight group-hover:text-primary transition-colors">{product.name}</CardTitle>
          </Link>
          <p className="text-sm text-muted-foreground mb-2">{product.category}</p>
          <div className="flex items-center mb-2">
            {renderStars(product.rating)}
            <span className="ml-2 text-xs text-muted-foreground">({product.reviewsCount} reviews)</span>
          </div>
          <p className="text-xl font-semibold text-primary">{formatPrice(product.price)}</p>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1" 
            onClick={handleAddToWishlist} 
            aria-label={`Add ${product.name} to wishlist`} 
            disabled={isAddingToWishlist || isAddingToCart}
          >
            {isAddingToWishlist ? (
              <Loader2 className="animate-spin h-4 w-4 mr-2" />
            ) : (
              <Heart className="mr-2 h-4 w-4" />
            )}
            {isAddingToWishlist ? "Adding..." : "Wishlist"}
          </Button>
          <Button 
            size="sm" 
            className="flex-1" 
            onClick={handleAddToCart} 
            aria-label={`Add ${product.name} to cart`} 
            disabled={isAddingToCart || isAddingToWishlist}
          >
            {isAddingToCart ? (
              <Loader2 className="animate-spin h-4 w-4 mr-2" />
            ) : (
              <ShoppingCart className="mr-2 h-4 w-4" />
            )}
            {isAddingToCart ? "Adding..." : "Add to Cart"}
          </Button>
        </CardFooter>
      </Card>
    </>
  );
}
