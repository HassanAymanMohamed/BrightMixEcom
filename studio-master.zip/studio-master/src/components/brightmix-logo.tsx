// src/components/brightmix-logo.tsx
"use client";
import React from 'react';

interface BrightMixLogoProps {
  className?: string;
  width?: number | string;
  height?: number | string;
  iconOnly?: boolean; // For contexts where only an icon/initials might be better
}

export const BrightMixLogo: React.FC<BrightMixLogoProps> = ({ className, width = "auto", height = "36px", iconOnly = false }) => {
  if (iconOnly) {
    return (
      <svg
        viewBox="0 0 40 40"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
        style={{ width: height, height: height }} // Use height for square icon
        aria-label="BrightMix Icon"
      >
        <style>
          {`
            .bm-icon-bg { fill: hsl(var(--primary)); }
            .bm-icon-text { font-family: 'Arial Black', Gadget, sans-serif; font-size: 20px; fill: hsl(var(--primary-foreground)); text-anchor: middle; dominant-baseline: central; }
          `}
        </style>
        <circle cx="20" cy="20" r="20" className="bm-icon-bg" />
        <text x="50%" y="50%" className="bm-icon-text">BM</text>
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 230 50" // Adjusted viewBox for better aspect ratio
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={{ width, height }}
      aria-label="BrightMix Logo"
    >
      <style>
        {`
          .bright-text-logo { font-family: 'Arial', sans-serif; font-size: 26px; font-weight: bold; fill: hsl(var(--primary)); }
          .mix-text-logo { font-family: 'Arial', sans-serif; font-size: 26px; font-weight: bold; fill: hsl(var(--accent)); }
          .reg-mark-logo { font-family: 'Arial', sans-serif; font-size: 7px; fill: hsl(var(--foreground)); }
          .tagline-text-logo { font-family: 'Arial', sans-serif; font-size: 8px; fill: hsl(var(--muted-foreground)); font-style: italic; }
        `}
      </style>
      <text x="5" y="28" className="bright-text-logo">Bright</text>
      <text x="88" y="28" className="mix-text-logo">Mix</text>
      <text x="145" y="19" className="reg-mark-logo">®</text>
      <text x="50" y="42" className="tagline-text-logo">Express Your vision</text>
    </svg>
  );
};
