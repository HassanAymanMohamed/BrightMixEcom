
"use client";

import React from 'react';
import { useLoading } from '@/contexts/loading-context';
import { LoadingScreen } from '@/components/global/loading-screen'; // Updated import

export function GlobalLoadingIndicator() {
  const { isLoading } = useLoading(); // Only need isLoading here, text is handled by LoadingScreen

  // LoadingScreen itself uses AnimatePresence and isLoading to manage visibility.
  // So, GlobalLoadingIndicator primarily just needs to render it.
  // No need to conditionally render LoadingScreen here based on isLoading,
  // as LoadingScreen handles its own presence.
  return <LoadingScreen />;
}
