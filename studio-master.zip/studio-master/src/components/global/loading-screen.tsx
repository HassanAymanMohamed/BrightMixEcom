
"use client";

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLoading } from '@/contexts/loading-context';

export function LoadingScreen() {
  const { isLoading, loadingText } = useLoading();

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-background/80 backdrop-blur-md"
          aria-modal="true"
          role="dialog"
          aria-labelledby="loading-text"
        >
          <motion.svg
            width="100"
            height="100"
            viewBox="0 0 100 100"
            aria-hidden="true" // Decorative SVG
          >
            {[15, 25, 35].map((radius, i) => (
              <motion.circle
                key={i}
                cx="50"
                cy="50"
                r={radius}
                stroke="hsl(var(--primary))"
                strokeWidth="2.5"
                fill="none"
                initial={{ opacity: 0.1, rotate: 0 }}
                animate={{
                  opacity: [0.3, 0.9, 0.3],
                  rotate: 360,
                }}
                transition={{
                  duration: 2.5 + i * 0.7,
                  ease: 'easeInOut',
                  repeat: Infinity,
                  opacity: {
                    duration: 2.0 + i * 0.5,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  },
                  rotate: { // Ensure rotate also has a distinct repeatType if needed or is part of the main loop
                    repeatType: "loop",
                    ease: "linear", // Linear for continuous rotation
                  }
                }}
              />
            ))}
          </motion.svg>
          <p id="loading-text" className="mt-6 text-lg font-medium text-foreground animate-pulse">
            {loadingText || "Loading..."}
          </p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
