
export const translations = {
  en: {
    header: {
      logo: "BrightMix", // Updated
      home: "Home",
      products: "Products",
      about: "About Us",
      contact: "Contact",
      searchPlaceholder: "Search products...",
      language: "Language",
      currency: "Currency",
      english: "English",
      arabic: "العربية",
      usd: "USD ($)",
      sar: "SAR (﷼)",
      wishlist: "Wishlist",
      cart: "Shopping Cart",
      account: "My Account",
      openMenu: "Open menu",
    },
    home: {
      title: "Discover BrightMix Finds", // Updated
      subtitle: "Unearth unique treasures and exquisite collections curated for the discerning eye.",
      shopAll: "Shop All Products",
      featuredProducts: "Featured Products",
      viewAllProducts: "View All Products",
      keySellingPoints: {
        shippingTitle: "Fast & Reliable Shipping",
        shippingDesc: "Get your finds delivered swiftly and securely to your doorstep.", // Updated
        giftingTitle: "Exquisite Gifting Options",
        giftingDesc: "Beautifully packaged gifts for your loved ones, perfect for any occasion.",
        checkoutTitle: "Secure & Easy Checkout",
        checkoutDesc: "Shop with confidence using our secure payment gateways and simple checkout.",
      },
      trendingCategories: "Trending Categories",
      aiSuggestions: "Just For You",
      aiSuggestionsDesc: "Personalized recommendations powered by AI, tailored to your unique style.",
      newsletterTitle: "Stay In The Loop",
      newsletterDesc: "Subscribe to our newsletter for exclusive updates, new arrivals, and special offers.",
      newsletterPlaceholder: "Enter your email address",
      subscribe: "Subscribe",
    },
    footer: {
      description: "Discover unique and exquisite products with BrightMix.", // Updated
      quickLinks: "Quick Links",
      aboutUs: "About Us",
      contactUs: "Contact Us",
      faq: "FAQ",
      shippingReturns: "Shipping & Returns",
      customerService: "Customer Service",
      orderTracking: "Order Tracking",
      termsConditions: "Terms & Conditions",
      privacyPolicy: "Privacy Policy",
      followUs: "Follow Us",
      newsletter: "Newsletter",
      yourEmail: "Your email",
      copyright: "BrightMix. All rights reserved.", // Updated
    }
  },
  ar: {
    header: {
      logo: "برايت ميكس", // Updated
      home: "الرئيسية",
      products: "المنتجات",
      about: "من نحن",
      contact: "اتصل بنا",
      searchPlaceholder: "ابحث عن المنتجات...",
      language: "اللغة",
      currency: "العملة",
      english: "English",
      arabic: "العربية",
      usd: "دولار أمريكي ($)",
      sar: "ريال سعودي (﷼)",
      wishlist: "قائمة الرغبات",
      cart: "سلة التسوق",
      account: "حسابي",
      openMenu: "فتح القائمة",
    },
    home: {
      title: "اكتشف برايت ميكس", // Updated
      subtitle: "اكتشف كنوزًا فريدة ومجموعات رائعة مُصممة خصيصًا لذوقك الرفيع.",
      shopAll: "تسوق كل المنتجات",
      featuredProducts: "المنتجات المميزة",
      viewAllProducts: "عرض كل المنتجات",
       keySellingPoints: {
        shippingTitle: "شحن سريع وموثوق",
        shippingDesc: "احصل على مشترياتك بسرعة وأمان حتى باب منزلك.", // Updated
        giftingTitle: "خيارات هدايا رائعة",
        giftingDesc: "هدايا مغلفة بشكل جميل لأحبائك، مثالية لجميع المناسبات.",
        checkoutTitle: "دفع آمن وسهل",
        checkoutDesc: "تسوق بثقة باستخدام بوابات الدفع الآمنة وعملية الدفع البسيطة.",
      },
      trendingCategories: "الفئات الرائجة",
      aiSuggestions: "خصيصاً لك",
      aiSuggestionsDesc: "توصيات مخصصة مدعومة بالذكاء الاصطناعي، مصممة لتناسب أسلوبك الفريد.",
      newsletterTitle: "ابق على اطلاع",
      newsletterDesc: "اشترك في نشرتنا الإخبارية للحصول على التحديثات الحصرية والمنتجات الجديدة والعروض الخاصة.",
      newsletterPlaceholder: "أدخل عنوان بريدك الإلكتروني",
      subscribe: "اشتراك",
    },
    footer: {
      description: "اكتشف منتجات فريدة ورائعة مع برايت ميكس.", // Updated
      quickLinks: "روابط سريعة",
      aboutUs: "من نحن",
      contactUs: "اتصل بنا",
      faq: "الأسئلة الشائعة",
      shippingReturns: "الشحن والإرجاع",
      customerService: "خدمة العملاء",
      orderTracking: "تتبع الطلب",
      termsConditions: "الشروط والأحكام",
      privacyPolicy: "سياسة الخصوصية",
      followUs: "تابعنا",
      newsletter: "النشرة الإخبارية",
      yourEmail: "بريدك الإلكتروني",
      copyright: "برايت ميكس. جميع الحقوق محفوظة.", // Updated
    }
  },
};

export type Translations = typeof translations.en;
