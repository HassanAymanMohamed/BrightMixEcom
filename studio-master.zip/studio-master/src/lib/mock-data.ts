export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  images: string[];
  brand: string;
  rating: number;
  reviewsCount: number;
  specifications?: { [key: string]: string };
  benefits?: string[];
  videoUrl?: string;
  colors?: string[];
  sizes?: string[];
  stock: number;
}

export const mockProducts: Product[] = [
  {
    id: "1",
    name: "Celestial Silk Scarf",
    description: "A luxurious silk scarf featuring an ethereal celestial print. Soft, elegant, and timeless.",
    price: 89.99,
    category: "Accessories",
    images: [
      "https://placehold.co/600x800.png?a=1",
      "https://placehold.co/600x800.png?a=2",
      "https://placehold.co/800x600.png?a=3",
    ],
    brand: "Ethereal Weaves",
    rating: 4.8,
    reviewsCount: 120,
    specifications: { Material: "100% Mulberry Silk", Dimensions: "90cm x 90cm", Care: "Dry clean only" },
    benefits: ["Hypoallergenic", "Breathable", "Adds a touch of elegance"],
    colors: ["Midnight Blue", "Cosmic Purple"],
    sizes: ["One Size"],
    stock: 15,
  },
  {
    id: "2",
    name: "Mystic Moonstone Ring",
    description: "An enchanting sterling silver ring set with a genuine rainbow moonstone. Believed to bring balance and hope.",
    price: 120.00,
    category: "Jewelry",
    images: [
      "https://placehold.co/600x600.png?b=1",
      "https://placehold.co/600x600.png?b=2",
    ],
    brand: "Lunar Gems",
    rating: 4.9,
    reviewsCount: 85,
    specifications: { Metal: "925 Sterling Silver", Gemstone: "Rainbow Moonstone", Weight: "5g" },
    benefits: ["Enhances intuition", "Calming energy", "Unique iridescent glow"],
    colors: ["Silver"],
    sizes: ["US 6", "US 7", "US 8"],
    stock: 22,
  },
  {
    id: "3",
    name: "Enchanted Forest Candle",
    description: "A hand-poured soy wax candle with a captivating blend of pine, cedarwood, and subtle floral notes.",
    price: 35.50,
    category: "Home Decor",
    images: [
      "https://placehold.co/500x700.png?c=1",
      "https://placehold.co/700x500.png?c=2",
    ],
    brand: "Whispering Woods",
    rating: 4.6,
    reviewsCount: 210,
    specifications: { Wax: "100% Soy Wax", Wick: "Cotton", BurnTime: "Approx. 50 hours", Scent: "Pine, Cedarwood, Floral" },
    benefits: ["Creates a relaxing ambiance", "Natural ingredients", "Long-lasting scent"],
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4", // Example video
    colors: ["Forest Green"],
    sizes: ["8 oz"],
    stock: 40,
  },
  {
    id: "4",
    name: "Dream Weaver Throw Blanket",
    description: "A soft, plush throw blanket perfect for cozy evenings. Features a subtle, dream-like pattern.",
    price: 75.00,
    category: "Home Goods",
    images: [
      "https://placehold.co/800x600.png?d=1",
      "https://placehold.co/800x600.png?d=2",
    ],
    brand: "Ethereal Weaves",
    rating: 4.7,
    reviewsCount: 95,
    specifications: { Material: "Microfiber Plush", Dimensions: "150cm x 200cm", Care: "Machine washable" },
    benefits: ["Ultra-soft and comfortable", "Warm and inviting", "Durable and easy to care for"],
    colors: ["Lavender Mist", "Silver Cloud"],
    sizes: ["Large"],
    stock: 12,
  },
  {
    id: "5",
    name: "Aurora Borealis Vase",
    description: "A stunning art glass vase inspired by the colors of the Northern Lights. Each piece is unique.",
    price: 150.00,
    category: "Home Decor",
    images: [
      "https://placehold.co/500x750.png?e=1",
      "https://placehold.co/500x750.png?e=2",
    ],
    brand: "Glasscape Arts",
    rating: 4.9,
    reviewsCount: 60,
    specifications: { Material: "Hand-blown Glass", Height: "30cm", Style: "Art Glass" },
    benefits: ["Unique statement piece", "Vibrant colors", "Handcrafted quality"],
    colors: ["Multi-color"],
    sizes: ["Medium"],
    stock: 8,
  },
  {
    id: "6",
    name: "Serene Spa Bath Set",
    description: "Indulge in a calming spa experience at home with this luxurious bath set. Includes bath bombs, oils, and salts.",
    price: 55.99,
    category: "Beauty & Wellness",
    images: [
      "https://placehold.co/700x700.png?f=1",
      "https://placehold.co/700x700.png?f=2",
    ],
    brand: "Tranquil Moments",
    rating: 4.5,
    reviewsCount: 150,
    specifications: { Includes: "3 Bath Bombs, Lavender Bath Oil, Himalayan Bath Salts", Ingredients: "Natural essential oils, Epsom salts" },
    benefits: ["Relaxes mind and body", "Nourishes skin", "Aromatherapeutic"],
    colors: ["Pastel Hues"],
    sizes: ["Standard Set"],
    stock: 30,
  },
];

export const categories = Array.from(new Set(mockProducts.map(p => p.category)));
export const brands = Array.from(new Set(mockProducts.map(p => p.brand)));

export const getProductById = (id: string): Product | undefined => {
  return mockProducts.find(p => p.id === id);
}