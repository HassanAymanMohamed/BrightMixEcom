// This file's content has been moved to src/contexts/localization-context.tsx
// This file can be removed if no longer referenced.
