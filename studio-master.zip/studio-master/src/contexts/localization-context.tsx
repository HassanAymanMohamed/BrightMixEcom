
"use client";

import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { translations, Translations } from '@/lib/translations';

export type Language = 'en' | 'ar';

export const currencyData = {
  USD: { symbol: '$', rate: 1, precision: 2, code: 'USD' },
  SAR: { symbol: 'SAR', rate: 3.75, precision: 2, code: 'SAR' },
};
export type Currency = keyof typeof currencyData;

interface LocalizationContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  translations: Translations;
  formatPrice: (valueInUSD: number, lang?: Language, curr?: Currency) => string;
}

const LocalizationContext = createContext<LocalizationContextType | undefined>(undefined);

export function LocalizationProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>('en');
  const [currency, setCurrencyState] = useState<Currency>('USD');

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const setCurrency = (curr: Currency) => {
    setCurrencyState(curr);
  };

  const formatPrice = (valueInUSD: number, lang: Language = language, curr: Currency = currency): string => {
    const targetRate = currencyData[curr].rate;
    const targetSymbol = currencyData[curr].symbol;
    const targetPrecision = currencyData[curr].precision;

    const convertedValue = valueInUSD * targetRate;

    const numStr = convertedValue.toLocaleString(lang, {
        minimumFractionDigits: targetPrecision,
        maximumFractionDigits: targetPrecision,
    });

    if (curr === 'USD' && lang === 'en') {
      return `${targetSymbol}${numStr}`;
    }
    return `${numStr} ${targetSymbol}`;
  };

  const currentTranslations = translations[language];

  return (
    <LocalizationContext.Provider value={{ language, setLanguage, currency, setCurrency, translations: currentTranslations, formatPrice }}>
      {children}
    </LocalizationContext.Provider>
  );
}

export function useLocalization() {
  const context = useContext(LocalizationContext);
  if (context === undefined) {
    throw new Error('useLocalization must be used within a LocalizationProvider');
  }
  return context;
}
